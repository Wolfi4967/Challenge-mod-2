tag @s add sb.self
tag @a[tag=sb.player,gamemode=survival,tag=!sb.self,distance=..48,sort=nearest,limit=1] add sb.partner
scoreboard players set #steps sb 0
execute if entity @a[tag=sb.partner] anchored eyes facing entity @a[tag=sb.partner,limit=1] eyes anchored feet positioned ~ ~1 ~ run function challenge:chain/line
tag @a remove sb.partner
tag @s remove sb.self
