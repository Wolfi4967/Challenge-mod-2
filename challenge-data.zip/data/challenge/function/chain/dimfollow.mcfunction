tag @s add sb.self
tag @a[tag=sb.player,gamemode=survival,tag=!sb.self,limit=1] add sb.partner
execute if entity @a[tag=sb.partner,distance=0..] run scoreboard players set @s sb.follow 0
execute unless entity @a[tag=sb.partner,distance=0..] if entity @a[tag=sb.partner] run scoreboard players add @s sb.follow 1
execute if score @s sb.follow matches 6.. if score @s sb.dimtime < @a[tag=sb.partner,limit=1] sb.dimtime run function challenge:chain/follow
tag @a remove sb.partner
tag @s remove sb.self
