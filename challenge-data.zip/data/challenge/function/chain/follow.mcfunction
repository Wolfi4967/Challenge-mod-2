tp @s @a[tag=sb.partner,limit=1]
scoreboard players set @s sb.follow 0
effect give @s minecraft:resistance 3 4 true
tellraw @s [{"text":"⚯ ","color":"gray"},{"text":"Die Kette hat dich hinterhergezogen!","color":"gray","italic":true}]
execute at @s run playsound minecraft:entity.enderman.teleport master @a ~ ~ ~ 1 0.6
