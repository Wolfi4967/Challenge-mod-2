scoreboard players add #steps sb 1
function challenge:chain/p
execute if score #steps sb matches 100.. run return 0
execute if entity @a[tag=sb.partner,distance=..1.2] run return 0
execute positioned ^ ^ ^0.5 run function challenge:chain/line
