execute store result score #n sb if entity @a[tag=sb.player,gamemode=survival]
execute if score #n sb matches ..1 run return 0
# Zug/Physik macht der Java-Teil des Mods (ChainPhysics), hier nur Optik + Dimensionen
# sichtbare Kette (alle 2 Ticks)
scoreboard players operation #par sb = #t sb
scoreboard players operation #par sb %= #2 sb.const
execute if score #par sb matches 0 as @a[tag=sb.player,gamemode=survival,limit=1] at @s run function challenge:chain/draw
# Dimensionen: die Kette zieht den Zurückgebliebenen hinterher
execute if score #t sb matches 5 as @a[tag=sb.player,gamemode=survival] at @s run function challenge:chain/dimtrack
execute if score #t sb matches 15 as @a[tag=sb.player,gamemode=survival] at @s run function challenge:chain/dimtrack
execute if score #t sb matches 5 as @a[tag=sb.player,gamemode=survival] at @s run function challenge:chain/dimfollow
execute if score #t sb matches 15 as @a[tag=sb.player,gamemode=survival] at @s run function challenge:chain/dimfollow
