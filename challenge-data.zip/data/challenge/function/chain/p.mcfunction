particle minecraft:dust{color:[0.45,0.45,0.5],scale:0.8} ~ ~ ~ 0 0 0 0 1 force @a
