scoreboard players set #d sb 0
execute if dimension minecraft:the_nether run scoreboard players set #d sb 1
execute if dimension minecraft:the_end run scoreboard players set #d sb 2
execute unless score @s sb.dim = #d sb run scoreboard players operation @s sb.dimtime = #ticks sb
scoreboard players operation @s sb.dim = #d sb
