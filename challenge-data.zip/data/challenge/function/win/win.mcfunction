scoreboard players set #state sb 3
execute as @a[tag=sb.player] run function challenge:mutation/clear_player
effect clear @a minecraft:hunger
bossbar set challenge:main name {"text":"♛ CHALLENGE GESCHAFFT ♛","color":"gold","bold":true}
bossbar set challenge:main color yellow
title @a times 10 120 40
title @a subtitle {"text":"Ziel erreicht – niemand hat aufgegeben.","color":"yellow"}
title @a title {"text":"GESCHAFFT!","color":"gold","bold":true}
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
execute as @a at @s run playsound minecraft:entity.firework_rocket.large_blast master @s ~ ~ ~ 1 1
execute as @a at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.6 1 0.6 0.4 150 normal @a
tellraw @a {"text":" "}
execute if score #goal sb.cfg matches 1 run tellraw @a [{"text":"♛ ","color":"gold"},{"text":"Geschafft! Ziel erreicht: ","color":"yellow"},{"text":"Enderdrache","color":"light_purple","bold":true}]
execute if score #goal sb.cfg matches 2 run tellraw @a [{"text":"♛ ","color":"gold"},{"text":"Geschafft! Ziel erreicht: ","color":"yellow"},{"text":"Wither","color":"dark_gray","bold":true}]
execute if score #goal sb.cfg matches 3 run tellraw @a [{"text":"♛ ","color":"gold"},{"text":"Geschafft! Ziel erreicht: ","color":"yellow"},{"text":"Wärter","color":"dark_aqua","bold":true}]
execute if score #goal sb.cfg matches 4 run tellraw @a [{"text":"♛ ","color":"gold"},{"text":"Geschafft! Ziel erreicht: ","color":"yellow"},{"text":"Ältester Wächter","color":"aqua","bold":true}]
execute if score #goal sb.cfg matches 5 run tellraw @a [{"text":"♛ ","color":"gold"},{"text":"Geschafft! Ziel erreicht: ","color":"yellow"},{"text":"Alle vier Bosse","color":"gold","bold":true}]
execute if score #goal sb.cfg matches 6 run tellraw @a [{"text":"♛ ","color":"gold"},{"text":"Geschafft! Ziel erreicht: ","color":"yellow"},{"text":"Seelenwelten: Der Zerrissene","color":"dark_purple","bold":true}]
function challenge:stats/print
