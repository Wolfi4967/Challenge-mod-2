execute if score #won_dragon sb matches 1 run return 0
execute if entity @a[tag=sb.player,advancements={minecraft:end/kill_dragon=true}] run return run function challenge:goal/got_dragon
execute as @e[type=minecraft:ender_dragon] store result score @s sb.tmp run data get entity @s DragonDeathTime
execute if entity @e[type=minecraft:ender_dragon,scores={sb.tmp=1..}] run return run function challenge:goal/got_dragon
# Fallback: aktivierter Austrittsportal in der Mitte des Ends
execute in minecraft:the_end positioned 2 0 0 positioned over world_surface if block ~ ~-1 ~ minecraft:end_portal run return run function challenge:goal/got_dragon
