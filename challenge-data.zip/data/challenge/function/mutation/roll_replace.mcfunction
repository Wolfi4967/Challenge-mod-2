scoreboard players operation #prev sb.mut = #current sb.mut
function challenge:mutation/reset_flags
execute store result score #new sb.mut run random value 1..20
execute if score #new sb.mut = #prev sb.mut run scoreboard players add #new sb.mut 1
execute if score #new sb.mut matches 21.. run scoreboard players set #new sb.mut 1
function challenge:mutation/activate
