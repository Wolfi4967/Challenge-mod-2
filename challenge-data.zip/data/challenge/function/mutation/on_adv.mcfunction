execute unless score #m_mut sb.cfg matches 1 run return 0
execute if score #m_perm sb.cfg matches 0 run tellraw @a {"text":"★ Neues Advancement – das Schicksal würfelt neu …","color":"yellow","italic":true}
execute if score #m_perm sb.cfg matches 1 run tellraw @a {"text":"★ Neues Advancement – eine weitere Mutation kommt dazu …","color":"yellow","italic":true}
function challenge:mutation/new
