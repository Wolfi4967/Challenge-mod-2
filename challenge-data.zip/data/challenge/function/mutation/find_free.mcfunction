scoreboard players set #isact sb 0
execute if score #new sb.mut matches 1 if score #a1 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 2 if score #a2 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 3 if score #a3 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 4 if score #a4 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 5 if score #a5 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 6 if score #a6 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 7 if score #a7 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 8 if score #a8 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 9 if score #a9 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 10 if score #a10 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 11 if score #a11 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 12 if score #a12 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 13 if score #a13 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 14 if score #a14 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 15 if score #a15 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 16 if score #a16 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 17 if score #a17 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 18 if score #a18 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 19 if score #a19 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #new sb.mut matches 20 if score #a20 sb.mut matches 1 run scoreboard players set #isact sb 1
execute if score #isact sb matches 0 run return 0
scoreboard players add #new sb.mut 1
execute if score #new sb.mut matches 21.. run scoreboard players set #new sb.mut 1
function challenge:mutation/find_free
