function challenge:mutation/count_adv
execute if score #adv sb > #adv_last sb run function challenge:mutation/on_adv
scoreboard players operation #adv_last sb = #adv sb
execute if score #m_mut sb.cfg matches 1 as @a[tag=sb.player] unless score @s sb.mut = #mver sb.mut run function challenge:mutation/sync
execute if score #a8 sb.mut matches 1 run effect give @a[tag=sb.player,gamemode=survival] minecraft:night_vision infinite 0 true
execute if score #a15 sb.mut matches 1 run effect give @a[tag=sb.player,gamemode=survival] minecraft:hunger infinite 0 true
