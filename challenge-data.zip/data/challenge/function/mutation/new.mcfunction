execute if score #m_perm sb.cfg matches 0 run return run function challenge:mutation/roll_replace
function challenge:mutation/roll_add
