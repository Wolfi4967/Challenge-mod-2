execute if score #count sb.mut matches 0 run bossbar set challenge:main name [{"text":"⚗ Noch keine Mutation","color":"white","bold":true},{"text":"  – holt euch ein Advancement …","color":"gray"}]
execute if score #count sb.mut matches 0 run bossbar set challenge:main color white
execute if score #count sb.mut matches 0 run return 0
execute if score #current sb.mut matches 1 run function challenge:mutation/bar/1
execute if score #current sb.mut matches 2 run function challenge:mutation/bar/2
execute if score #current sb.mut matches 3 run function challenge:mutation/bar/3
execute if score #current sb.mut matches 4 run function challenge:mutation/bar/4
execute if score #current sb.mut matches 5 run function challenge:mutation/bar/5
execute if score #current sb.mut matches 6 run function challenge:mutation/bar/6
execute if score #current sb.mut matches 7 run function challenge:mutation/bar/7
execute if score #current sb.mut matches 8 run function challenge:mutation/bar/8
execute if score #current sb.mut matches 9 run function challenge:mutation/bar/9
execute if score #current sb.mut matches 10 run function challenge:mutation/bar/10
execute if score #current sb.mut matches 11 run function challenge:mutation/bar/11
execute if score #current sb.mut matches 12 run function challenge:mutation/bar/12
execute if score #current sb.mut matches 13 run function challenge:mutation/bar/13
execute if score #current sb.mut matches 14 run function challenge:mutation/bar/14
execute if score #current sb.mut matches 15 run function challenge:mutation/bar/15
execute if score #current sb.mut matches 16 run function challenge:mutation/bar/16
execute if score #current sb.mut matches 17 run function challenge:mutation/bar/17
execute if score #current sb.mut matches 18 run function challenge:mutation/bar/18
execute if score #current sb.mut matches 19 run function challenge:mutation/bar/19
execute if score #current sb.mut matches 20 run function challenge:mutation/bar/20
