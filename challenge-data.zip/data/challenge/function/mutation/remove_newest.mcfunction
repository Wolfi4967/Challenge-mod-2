execute unless score #count sb.mut matches 1.. run return 0
execute store result score #rm sb.mut run data get storage challenge:mut stack[-1]
data remove storage challenge:mut stack[-1]
execute if score #rm sb.mut matches 1 run scoreboard players set #a1 sb.mut 0
execute if score #rm sb.mut matches 2 run scoreboard players set #a2 sb.mut 0
execute if score #rm sb.mut matches 3 run scoreboard players set #a3 sb.mut 0
execute if score #rm sb.mut matches 4 run scoreboard players set #a4 sb.mut 0
execute if score #rm sb.mut matches 5 run scoreboard players set #a5 sb.mut 0
execute if score #rm sb.mut matches 6 run scoreboard players set #a6 sb.mut 0
execute if score #rm sb.mut matches 7 run scoreboard players set #a7 sb.mut 0
execute if score #rm sb.mut matches 8 run scoreboard players set #a8 sb.mut 0
execute if score #rm sb.mut matches 9 run scoreboard players set #a9 sb.mut 0
execute if score #rm sb.mut matches 10 run scoreboard players set #a10 sb.mut 0
execute if score #rm sb.mut matches 11 run scoreboard players set #a11 sb.mut 0
execute if score #rm sb.mut matches 12 run scoreboard players set #a12 sb.mut 0
execute if score #rm sb.mut matches 13 run scoreboard players set #a13 sb.mut 0
execute if score #rm sb.mut matches 14 run scoreboard players set #a14 sb.mut 0
execute if score #rm sb.mut matches 15 run scoreboard players set #a15 sb.mut 0
execute if score #rm sb.mut matches 16 run scoreboard players set #a16 sb.mut 0
execute if score #rm sb.mut matches 17 run scoreboard players set #a17 sb.mut 0
execute if score #rm sb.mut matches 18 run scoreboard players set #a18 sb.mut 0
execute if score #rm sb.mut matches 19 run scoreboard players set #a19 sb.mut 0
execute if score #rm sb.mut matches 20 run scoreboard players set #a20 sb.mut 0
execute if score #rm sb.mut matches 1 run function challenge:mutation/removed/1
execute if score #rm sb.mut matches 2 run function challenge:mutation/removed/2
execute if score #rm sb.mut matches 3 run function challenge:mutation/removed/3
execute if score #rm sb.mut matches 4 run function challenge:mutation/removed/4
execute if score #rm sb.mut matches 5 run function challenge:mutation/removed/5
execute if score #rm sb.mut matches 6 run function challenge:mutation/removed/6
execute if score #rm sb.mut matches 7 run function challenge:mutation/removed/7
execute if score #rm sb.mut matches 8 run function challenge:mutation/removed/8
execute if score #rm sb.mut matches 9 run function challenge:mutation/removed/9
execute if score #rm sb.mut matches 10 run function challenge:mutation/removed/10
execute if score #rm sb.mut matches 11 run function challenge:mutation/removed/11
execute if score #rm sb.mut matches 12 run function challenge:mutation/removed/12
execute if score #rm sb.mut matches 13 run function challenge:mutation/removed/13
execute if score #rm sb.mut matches 14 run function challenge:mutation/removed/14
execute if score #rm sb.mut matches 15 run function challenge:mutation/removed/15
execute if score #rm sb.mut matches 16 run function challenge:mutation/removed/16
execute if score #rm sb.mut matches 17 run function challenge:mutation/removed/17
execute if score #rm sb.mut matches 18 run function challenge:mutation/removed/18
execute if score #rm sb.mut matches 19 run function challenge:mutation/removed/19
execute if score #rm sb.mut matches 20 run function challenge:mutation/removed/20
scoreboard players remove #count sb.mut 1
scoreboard players add #mver sb.mut 1
scoreboard players set #current sb.mut 0
execute if data storage challenge:mut stack[-1] store result score #current sb.mut run data get storage challenge:mut stack[-1]
execute as @a[tag=sb.player] run function challenge:mutation/sync
function challenge:mutation/bossbar
