title @a[tag=sb.player] times 5 50 15
title @a[tag=sb.player] subtitle [{"text":"✖ Fluch  ","color":"red"},{"text":"−20 % Lauftempo und niedrigere Sprünge","color":"gray"}]
title @a[tag=sb.player] title {"text":"Bleifüße","color":"red","bold":true}
execute if score #m_perm sb.cfg matches 0 run tellraw @a [{"text":"⚗ Neue Mutation: ","color":"dark_purple"},{"text":"Bleifüße","color":"red","bold":true,"hover_event":{"action":"show_text","value":{"text":"−20 % Lauftempo und niedrigere Sprünge"}}},{"text":" (✖ Fluch)","color":"red"},{"text":" – −20 % Lauftempo und niedrigere Sprünge","color":"gray"}]
execute if score #m_perm sb.cfg matches 1 run tellraw @a [{"text":"⚗ Dauerhafte Mutation dazu: ","color":"dark_purple"},{"text":"Bleifüße","color":"red","bold":true,"hover_event":{"action":"show_text","value":{"text":"−20 % Lauftempo und niedrigere Sprünge"}}},{"text":" (✖ Fluch)","color":"red"},{"text":" – −20 % Lauftempo und niedrigere Sprünge","color":"gray"}]
execute as @a at @s run playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 0.35 1.2
