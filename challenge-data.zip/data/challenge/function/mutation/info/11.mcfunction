title @a[tag=sb.player] times 5 50 15
title @a[tag=sb.player] subtitle [{"text":"✖ Fluch  ","color":"red"},{"text":"Doppelter Fallschaden, schon ab 2 Blöcken","color":"gray"}]
title @a[tag=sb.player] title {"text":"Morsche Knochen","color":"red","bold":true}
execute if score #m_perm sb.cfg matches 0 run tellraw @a [{"text":"⚗ Neue Mutation: ","color":"dark_purple"},{"text":"Morsche Knochen","color":"red","bold":true,"hover_event":{"action":"show_text","value":{"text":"Doppelter Fallschaden, schon ab 2 Blöcken"}}},{"text":" (✖ Fluch)","color":"red"},{"text":" – Doppelter Fallschaden, schon ab 2 Blöcken","color":"gray"}]
execute if score #m_perm sb.cfg matches 1 run tellraw @a [{"text":"⚗ Dauerhafte Mutation dazu: ","color":"dark_purple"},{"text":"Morsche Knochen","color":"red","bold":true,"hover_event":{"action":"show_text","value":{"text":"Doppelter Fallschaden, schon ab 2 Blöcken"}}},{"text":" (✖ Fluch)","color":"red"},{"text":" – Doppelter Fallschaden, schon ab 2 Blöcken","color":"gray"}]
execute as @a at @s run playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 0.35 1.2
