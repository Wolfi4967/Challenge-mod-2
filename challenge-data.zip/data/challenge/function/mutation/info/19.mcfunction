title @a[tag=sb.player] times 5 50 15
title @a[tag=sb.player] subtitle [{"text":"✦ Chaos  ","color":"light_purple"},{"text":"+70 % Sprungkraft, halber Fallschaden","color":"gray"}]
title @a[tag=sb.player] title {"text":"Hüpfburg","color":"light_purple","bold":true}
execute if score #m_perm sb.cfg matches 0 run tellraw @a [{"text":"⚗ Neue Mutation: ","color":"dark_purple"},{"text":"Hüpfburg","color":"light_purple","bold":true,"hover_event":{"action":"show_text","value":{"text":"+70 % Sprungkraft, halber Fallschaden"}}},{"text":" (✦ Chaos)","color":"light_purple"},{"text":" – +70 % Sprungkraft, halber Fallschaden","color":"gray"}]
execute if score #m_perm sb.cfg matches 1 run tellraw @a [{"text":"⚗ Dauerhafte Mutation dazu: ","color":"dark_purple"},{"text":"Hüpfburg","color":"light_purple","bold":true,"hover_event":{"action":"show_text","value":{"text":"+70 % Sprungkraft, halber Fallschaden"}}},{"text":" (✦ Chaos)","color":"light_purple"},{"text":" – +70 % Sprungkraft, halber Fallschaden","color":"gray"}]
execute as @a at @s run playsound minecraft:entity.illusioner.mirror_move master @s ~ ~ ~ 1 0.8
