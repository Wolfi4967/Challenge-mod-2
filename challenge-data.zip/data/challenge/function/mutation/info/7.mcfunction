title @a[tag=sb.player] times 5 50 15
title @a[tag=sb.player] subtitle [{"text":"✚ Segen  ","color":"green"},{"text":"+3 Herzen maximales Leben","color":"gray"}]
title @a[tag=sb.player] title {"text":"Extraherzen","color":"green","bold":true}
execute if score #m_perm sb.cfg matches 0 run tellraw @a [{"text":"⚗ Neue Mutation: ","color":"dark_purple"},{"text":"Extraherzen","color":"green","bold":true,"hover_event":{"action":"show_text","value":{"text":"+3 Herzen maximales Leben"}}},{"text":" (✚ Segen)","color":"green"},{"text":" – +3 Herzen maximales Leben","color":"gray"}]
execute if score #m_perm sb.cfg matches 1 run tellraw @a [{"text":"⚗ Dauerhafte Mutation dazu: ","color":"dark_purple"},{"text":"Extraherzen","color":"green","bold":true,"hover_event":{"action":"show_text","value":{"text":"+3 Herzen maximales Leben"}}},{"text":" (✚ Segen)","color":"green"},{"text":" – +3 Herzen maximales Leben","color":"gray"}]
execute as @a at @s run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.8 1.4
