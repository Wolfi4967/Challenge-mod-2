title @a[tag=sb.player] times 5 50 15
title @a[tag=sb.player] subtitle [{"text":"✦ Chaos  ","color":"light_purple"},{"text":"Halb so groß und +15 % Tempo, aber −2 Herzen","color":"gray"}]
title @a[tag=sb.player] title {"text":"Zwerg","color":"light_purple","bold":true}
execute if score #m_perm sb.cfg matches 0 run tellraw @a [{"text":"⚗ Neue Mutation: ","color":"dark_purple"},{"text":"Zwerg","color":"light_purple","bold":true,"hover_event":{"action":"show_text","value":{"text":"Halb so groß und +15 % Tempo, aber −2 Herzen"}}},{"text":" (✦ Chaos)","color":"light_purple"},{"text":" – Halb so groß und +15 % Tempo, aber −2 Herzen","color":"gray"}]
execute if score #m_perm sb.cfg matches 1 run tellraw @a [{"text":"⚗ Dauerhafte Mutation dazu: ","color":"dark_purple"},{"text":"Zwerg","color":"light_purple","bold":true,"hover_event":{"action":"show_text","value":{"text":"Halb so groß und +15 % Tempo, aber −2 Herzen"}}},{"text":" (✦ Chaos)","color":"light_purple"},{"text":" – Halb so groß und +15 % Tempo, aber −2 Herzen","color":"gray"}]
execute as @a at @s run playsound minecraft:entity.illusioner.mirror_move master @s ~ ~ ~ 1 0.8
