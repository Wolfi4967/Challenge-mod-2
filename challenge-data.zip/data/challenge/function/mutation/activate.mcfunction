execute if score #new sb.mut matches 1 run scoreboard players set #a1 sb.mut 1
execute if score #new sb.mut matches 2 run scoreboard players set #a2 sb.mut 1
execute if score #new sb.mut matches 3 run scoreboard players set #a3 sb.mut 1
execute if score #new sb.mut matches 4 run scoreboard players set #a4 sb.mut 1
execute if score #new sb.mut matches 5 run scoreboard players set #a5 sb.mut 1
execute if score #new sb.mut matches 6 run scoreboard players set #a6 sb.mut 1
execute if score #new sb.mut matches 7 run scoreboard players set #a7 sb.mut 1
execute if score #new sb.mut matches 8 run scoreboard players set #a8 sb.mut 1
execute if score #new sb.mut matches 9 run scoreboard players set #a9 sb.mut 1
execute if score #new sb.mut matches 10 run scoreboard players set #a10 sb.mut 1
execute if score #new sb.mut matches 11 run scoreboard players set #a11 sb.mut 1
execute if score #new sb.mut matches 12 run scoreboard players set #a12 sb.mut 1
execute if score #new sb.mut matches 13 run scoreboard players set #a13 sb.mut 1
execute if score #new sb.mut matches 14 run scoreboard players set #a14 sb.mut 1
execute if score #new sb.mut matches 15 run scoreboard players set #a15 sb.mut 1
execute if score #new sb.mut matches 16 run scoreboard players set #a16 sb.mut 1
execute if score #new sb.mut matches 17 run scoreboard players set #a17 sb.mut 1
execute if score #new sb.mut matches 18 run scoreboard players set #a18 sb.mut 1
execute if score #new sb.mut matches 19 run scoreboard players set #a19 sb.mut 1
execute if score #new sb.mut matches 20 run scoreboard players set #a20 sb.mut 1
scoreboard players operation #current sb.mut = #new sb.mut
scoreboard players add #count sb.mut 1
scoreboard players add #mver sb.mut 1
scoreboard players add #rerolls sb 1
execute store result storage challenge:mut tmp int 1 run scoreboard players get #new sb.mut
data modify storage challenge:mut stack append from storage challenge:mut tmp
# 5 Sekunden Schutz, damit z.B. 'Riese' im engen Tunnel nicht sofort erstickt
effect give @a[tag=sb.player,gamemode=survival] minecraft:resistance 5 4 true
execute as @a[tag=sb.player] run function challenge:mutation/sync
execute if score #new sb.mut matches 7 unless score #m_uhc sb.cfg matches 1 run effect give @a[tag=sb.player,gamemode=survival] minecraft:instant_health 1 0 true
execute if score #new sb.mut matches 1 run function challenge:mutation/info/1
execute if score #new sb.mut matches 2 run function challenge:mutation/info/2
execute if score #new sb.mut matches 3 run function challenge:mutation/info/3
execute if score #new sb.mut matches 4 run function challenge:mutation/info/4
execute if score #new sb.mut matches 5 run function challenge:mutation/info/5
execute if score #new sb.mut matches 6 run function challenge:mutation/info/6
execute if score #new sb.mut matches 7 run function challenge:mutation/info/7
execute if score #new sb.mut matches 8 run function challenge:mutation/info/8
execute if score #new sb.mut matches 9 run function challenge:mutation/info/9
execute if score #new sb.mut matches 10 run function challenge:mutation/info/10
execute if score #new sb.mut matches 11 run function challenge:mutation/info/11
execute if score #new sb.mut matches 12 run function challenge:mutation/info/12
execute if score #new sb.mut matches 13 run function challenge:mutation/info/13
execute if score #new sb.mut matches 14 run function challenge:mutation/info/14
execute if score #new sb.mut matches 15 run function challenge:mutation/info/15
execute if score #new sb.mut matches 16 run function challenge:mutation/info/16
execute if score #new sb.mut matches 17 run function challenge:mutation/info/17
execute if score #new sb.mut matches 18 run function challenge:mutation/info/18
execute if score #new sb.mut matches 19 run function challenge:mutation/info/19
execute if score #new sb.mut matches 20 run function challenge:mutation/info/20
function challenge:mutation/bossbar
