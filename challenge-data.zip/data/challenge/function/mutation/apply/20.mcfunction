attribute @s minecraft:movement_speed modifier add challenge:mut_20 0.4 add_multiplied_base
attribute @s minecraft:block_break_speed modifier add challenge:mut_20 0.3 add_multiplied_base
attribute @s minecraft:max_health modifier add challenge:mut_20 -4 add_value
