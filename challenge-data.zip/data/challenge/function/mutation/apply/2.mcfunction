attribute @s minecraft:step_height modifier add challenge:mut_2 0.5 add_value
attribute @s minecraft:jump_strength modifier add challenge:mut_2 0.2 add_multiplied_base
attribute @s minecraft:safe_fall_distance modifier add challenge:mut_2 1 add_value
