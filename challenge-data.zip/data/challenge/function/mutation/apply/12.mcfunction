attribute @s minecraft:attack_damage modifier add challenge:mut_12 -0.35 add_multiplied_total
attribute @s minecraft:block_break_speed modifier add challenge:mut_12 -0.35 add_multiplied_base
