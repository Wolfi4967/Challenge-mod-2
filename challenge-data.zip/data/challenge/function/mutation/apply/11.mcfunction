attribute @s minecraft:fall_damage_multiplier modifier add challenge:mut_11 1 add_value
attribute @s minecraft:safe_fall_distance modifier add challenge:mut_11 -1 add_value
