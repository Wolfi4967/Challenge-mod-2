attribute @s minecraft:jump_strength modifier add challenge:mut_19 0.7 add_multiplied_base
attribute @s minecraft:fall_damage_multiplier modifier add challenge:mut_19 -0.5 add_value
