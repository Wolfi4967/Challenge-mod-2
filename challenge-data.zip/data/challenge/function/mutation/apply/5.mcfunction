attribute @s minecraft:block_break_speed modifier add challenge:mut_5 0.6 add_multiplied_base
