attribute @s minecraft:block_interaction_range modifier add challenge:mut_4 2 add_value
attribute @s minecraft:entity_interaction_range modifier add challenge:mut_4 1.5 add_value
