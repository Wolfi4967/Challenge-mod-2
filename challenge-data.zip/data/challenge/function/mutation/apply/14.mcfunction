attribute @s minecraft:burning_time modifier add challenge:mut_14 2 add_multiplied_base
