attribute @s minecraft:scale modifier add challenge:mut_17 -0.5 add_multiplied_base
attribute @s minecraft:max_health modifier add challenge:mut_17 -4 add_value
attribute @s minecraft:movement_speed modifier add challenge:mut_17 0.15 add_multiplied_base
