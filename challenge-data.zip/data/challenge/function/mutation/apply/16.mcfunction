attribute @s minecraft:scale modifier add challenge:mut_16 0.3 add_multiplied_base
attribute @s minecraft:max_health modifier add challenge:mut_16 4 add_value
attribute @s minecraft:block_interaction_range modifier add challenge:mut_16 1 add_value
attribute @s minecraft:entity_interaction_range modifier add challenge:mut_16 1 add_value
