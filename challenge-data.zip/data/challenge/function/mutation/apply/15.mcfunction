effect give @s minecraft:hunger infinite 0 true
scoreboard players set @s sb.mhu 1
