attribute @s minecraft:block_interaction_range modifier add challenge:mut_13 -1.5 add_value
attribute @s minecraft:entity_interaction_range modifier add challenge:mut_13 -0.75 add_value
