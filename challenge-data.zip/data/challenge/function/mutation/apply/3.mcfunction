attribute @s minecraft:armor modifier add challenge:mut_3 4 add_value
attribute @s minecraft:knockback_resistance modifier add challenge:mut_3 0.5 add_value
