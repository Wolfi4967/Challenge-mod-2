attribute @s minecraft:gravity modifier add challenge:mut_18 -0.5 add_multiplied_base
attribute @s minecraft:safe_fall_distance modifier add challenge:mut_18 3 add_value
