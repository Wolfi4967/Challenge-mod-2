attribute @s minecraft:movement_speed modifier add challenge:mut_10 -0.2 add_multiplied_base
attribute @s minecraft:jump_strength modifier add challenge:mut_10 -0.08 add_multiplied_base
