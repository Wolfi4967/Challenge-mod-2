attribute @s minecraft:movement_speed modifier add challenge:mut_1 0.25 add_multiplied_base
