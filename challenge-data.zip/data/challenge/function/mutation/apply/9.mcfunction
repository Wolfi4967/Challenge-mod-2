attribute @s minecraft:max_health modifier add challenge:mut_9 -6 add_value
