attribute @s minecraft:attack_damage modifier add challenge:mut_6 0.5 add_multiplied_total
