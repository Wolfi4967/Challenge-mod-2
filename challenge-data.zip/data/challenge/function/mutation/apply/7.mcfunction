attribute @s minecraft:max_health modifier add challenge:mut_7 6 add_value
