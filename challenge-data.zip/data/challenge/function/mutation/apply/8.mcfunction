effect give @s minecraft:night_vision infinite 0 true
scoreboard players set @s sb.mnv 1
