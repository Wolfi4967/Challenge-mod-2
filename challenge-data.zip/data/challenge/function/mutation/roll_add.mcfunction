execute if score #count sb.mut matches 20.. run return run tellraw @a {"text":"⚗ Alle 20 Mutationen sind schon aktiv – mehr Chaos geht nicht!","color":"light_purple","bold":true}
execute store result score #new sb.mut run random value 1..20
function challenge:mutation/find_free
function challenge:mutation/activate
