execute if score #m_perm sb.cfg matches 0 run bossbar set challenge:main name [{"text":"⚗ ","color":"white"},{"text":"Extraherzen","color":"green","bold":true},{"text":"  ✚  +3 Herzen maximales Leben","color":"gray"}]
execute if score #m_perm sb.cfg matches 1 run bossbar set challenge:main name [{"text":"⚗ ","color":"white"},{"score":{"name":"#count","objective":"sb.mut"},"color":"white","bold":true},{"text":" Mutationen aktiv","color":"white","bold":true},{"text":"  •  neueste: ","color":"gray"},{"text":"Extraherzen","color":"green","bold":true}]
bossbar set challenge:main color green
