execute if score #m_perm sb.cfg matches 0 run bossbar set challenge:main name [{"text":"⚗ ","color":"white"},{"text":"Zunder","color":"red","bold":true},{"text":"  ✖  Feuer brennt dreimal so lange an euch","color":"gray"}]
execute if score #m_perm sb.cfg matches 1 run bossbar set challenge:main name [{"text":"⚗ ","color":"white"},{"score":{"name":"#count","objective":"sb.mut"},"color":"white","bold":true},{"text":" Mutationen aktiv","color":"white","bold":true},{"text":"  •  neueste: ","color":"gray"},{"text":"Zunder","color":"red","bold":true}]
bossbar set challenge:main color red
