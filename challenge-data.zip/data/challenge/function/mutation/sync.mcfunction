function challenge:mutation/clear_player
execute if score #a1 sb.mut matches 1 run function challenge:mutation/apply/1
execute if score #a2 sb.mut matches 1 run function challenge:mutation/apply/2
execute if score #a3 sb.mut matches 1 run function challenge:mutation/apply/3
execute if score #a4 sb.mut matches 1 run function challenge:mutation/apply/4
execute if score #a5 sb.mut matches 1 run function challenge:mutation/apply/5
execute if score #a6 sb.mut matches 1 run function challenge:mutation/apply/6
execute if score #a7 sb.mut matches 1 run function challenge:mutation/apply/7
execute if score #a8 sb.mut matches 1 run function challenge:mutation/apply/8
execute if score #a9 sb.mut matches 1 run function challenge:mutation/apply/9
execute if score #a10 sb.mut matches 1 run function challenge:mutation/apply/10
execute if score #a11 sb.mut matches 1 run function challenge:mutation/apply/11
execute if score #a12 sb.mut matches 1 run function challenge:mutation/apply/12
execute if score #a13 sb.mut matches 1 run function challenge:mutation/apply/13
execute if score #a14 sb.mut matches 1 run function challenge:mutation/apply/14
execute if score #a15 sb.mut matches 1 run function challenge:mutation/apply/15
execute if score #a16 sb.mut matches 1 run function challenge:mutation/apply/16
execute if score #a17 sb.mut matches 1 run function challenge:mutation/apply/17
execute if score #a18 sb.mut matches 1 run function challenge:mutation/apply/18
execute if score #a19 sb.mut matches 1 run function challenge:mutation/apply/19
execute if score #a20 sb.mut matches 1 run function challenge:mutation/apply/20
scoreboard players operation @s sb.mut = #mver sb.mut
