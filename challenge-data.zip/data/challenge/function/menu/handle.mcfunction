# 1 Hauptmenü (Dialog) | 2 Einstellungen (Dialog) | 3 Chat-Menü | 10 Start | 11 Pause | 12 Regeln (Dialog) | 14 Regeln (Chat)
# 9 Fenster schließen | 15 Deaktivieren (Rückfrage) | 16 Deaktivieren | 17 Wieder aktivieren
# 4 Seite Chaos (Dialog) | 21-29 Module (Chat) | 31-33 Presets (Chat) | 41-43 Presets (Dialog)
# 5 Seite Ziel & Leben (Dialog) | Speichern läuft über den Mod-Befehl /challenge apply
execute if score @s challenge matches 1 run function challenge:ui/open_main
execute if score @s challenge matches 2 run function challenge:ui/open_settings
execute if score @s challenge matches 4 run function challenge:ui/open_chaos
execute if score @s challenge matches 3 run function challenge:menu/show
execute if score @s challenge matches 9 run dialog clear @s
execute if score @s challenge matches 10 run function challenge:cmd/start_logic
execute if score @s challenge matches 11 run function challenge:menu/pause
execute if score @s challenge matches 12 run function challenge:ui/open_rules
execute if score @s challenge matches 13 run function challenge:stats/print
execute if score @s challenge matches 14 run function challenge:menu/rules
execute if score @s challenge matches 15 run function challenge:cmd/disable_ask
execute if score @s challenge matches 16 run function challenge:game/disable
execute if score @s challenge matches 17 run function challenge:game/to_lobby_menu
execute if score @s challenge matches 20..39 run function challenge:menu/settings
execute if score @s challenge matches 41..43 run function challenge:settings/dialog_preset
execute if score @s challenge matches 5 run function challenge:ui/open_goal
execute if score @s challenge matches 6 run function challenge:ui/open_world
scoreboard players set @s challenge 0
