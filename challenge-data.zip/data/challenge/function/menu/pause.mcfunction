# offenes Menüfenster schließen (die Fenster bleiben nach einem Klick offen, bis der Server antwortet)
execute if entity @s run dialog clear @s
execute unless score #state sb matches 1 run return run tellraw @s {"text":"✖ Pausieren geht nur, während die Challenge läuft.","color":"red"}
execute if score #paused sb matches 0 run return run function challenge:pause/on
function challenge:pause/off
