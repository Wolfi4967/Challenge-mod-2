execute unless score #state sb matches 0 run return run tellraw @s {"text":"✖ Einstellungen können nur vor dem Start geändert werden.","color":"red"}
execute if score #countdown sb matches 1.. run return run tellraw @s {"text":"✖ Der Countdown läuft schon.","color":"red"}
execute if score @s challenge matches 21 store success score #m_schmerz sb.cfg if score #m_schmerz sb.cfg matches 0
execute if score @s challenge matches 22 store success score #m_band sb.cfg if score #m_band sb.cfg matches 0
execute if score @s challenge matches 23 store success score #m_mut sb.cfg if score #m_mut sb.cfg matches 0
execute if score @s challenge matches 24 store success score #m_rest sb.cfg if score #m_rest sb.cfg matches 0
execute if score @s challenge matches 25 store success score #m_perm sb.cfg if score #m_perm sb.cfg matches 0
execute if score @s challenge matches 26 store success score #m_uhc sb.cfg if score #m_uhc sb.cfg matches 0
execute if score @s challenge matches 27 store success score #m_chain sb.cfg if score #m_chain sb.cfg matches 0
execute if score @s challenge matches 28 store success score #m_mobrand sb.cfg if score #m_mobrand sb.cfg matches 0
execute if score @s challenge matches 29 store success score #m_fx sb.cfg if score #m_fx sb.cfg matches 0
execute if score @s challenge matches 20 store success score #m_brand sb.cfg if score #m_brand sb.cfg matches 0
execute if score @s challenge matches 34 run scoreboard players add #goal sb.cfg 1
execute if score @s challenge matches 34 if score #goal sb.cfg matches 6.. run scoreboard players set #goal sb.cfg 1
execute if score @s challenge matches 35 run scoreboard players add #death sb.cfg 1
execute if score @s challenge matches 35 if score #death sb.cfg matches 3.. run scoreboard players set #death sb.cfg 1
execute if score @s challenge matches 31..33 run function challenge:settings/preset
function challenge:settings/sync
tellraw @a [{"selector":"@s","color":"yellow"},{"text":" hat die Einstellungen geändert.","color":"gray"}]
execute as @a run function challenge:menu/show
