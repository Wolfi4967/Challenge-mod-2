execute as @a[tag=sb.player,gamemode=survival] run function challenge:pause/freeze
effect give @a[tag=sb.frozen] minecraft:saturation 2 0 true
