gamemode adventure @s
tag @s add sb.frozen
attribute @s minecraft:movement_speed modifier add challenge:pause -1 add_multiplied_total
attribute @s minecraft:jump_strength modifier add challenge:pause -1 add_multiplied_total
effect give @s minecraft:resistance infinite 4 true
