scoreboard players set #paused sb 1
execute as @a[tag=sb.player,gamemode=survival] run function challenge:pause/freeze
scoreboard players set @a sb.dmg 0
title @a times 5 40 10
title @a subtitle [{"selector":"@s","color":"yellow"},{"text":" hat pausiert","color":"gray"}]
title @a title {"text":"⏸ PAUSE","color":"gold","bold":true}
execute as @a at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.7
