scoreboard players set @a sb.dmg 0
execute if score #t sb matches 0 run function challenge:pause/second
