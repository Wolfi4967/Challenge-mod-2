gamemode survival @s
tag @s remove sb.frozen
attribute @s minecraft:movement_speed modifier remove challenge:pause
attribute @s minecraft:jump_strength modifier remove challenge:pause
effect clear @s minecraft:resistance
