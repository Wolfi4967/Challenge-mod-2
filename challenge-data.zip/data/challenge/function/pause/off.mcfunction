scoreboard players set #paused sb 0
execute as @a[tag=sb.frozen] run function challenge:pause/unfreeze
scoreboard players set @a sb.dmg 0
title @a times 5 30 10
title @a subtitle [{"selector":"@s","color":"yellow"},{"text":" setzt fort","color":"gray"}]
title @a title {"text":"▶ WEITER","color":"green","bold":true}
execute as @a at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
