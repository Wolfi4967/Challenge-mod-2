# Rollen: 1 = Himmelsreich, 2 = Tiefenreich (zufällig; alle weiteren Spieler abwechselnd)
scoreboard players set @a[tag=sb.player] sb.role 0
scoreboard players set @r[tag=sb.player,scores={sb.role=0}] sb.role 1
scoreboard players set @r[tag=sb.player,scores={sb.role=0}] sb.role 2
scoreboard players set @r[tag=sb.player,scores={sb.role=0}] sb.role 1
scoreboard players set @a[tag=sb.player,scores={sb.role=0}] sb.role 2
# Seelenband und Kette ergeben in getrennten Welten keinen Sinn
scoreboard players set #m_band sb.cfg 0
scoreboard players set #m_chain sb.cfg 0
function challenge:settings/sync
effect give @a[tag=sb.player] minecraft:resistance 15 4 true
effect give @a[tag=sb.player] minecraft:slow_falling 15 0 true
scoreboard players set #sw_start sb 1
tellraw @a [{"text":"☯ Seelenwelten: ","color":"dark_purple","bold":true},{"text":"Ihr werdet getrennt. ","color":"gray"},{"selector":"@a[tag=sb.player,scores={sb.role=1}]","color":"aqua"},{"text":" erwacht im Himmelsreich, ","color":"gray"},{"selector":"@a[tag=sb.player,scores={sb.role=2}]","color":"red"},{"text":" im Tiefenreich.","color":"gray"}]
tellraw @a [{"text":"   Euer ","color":"gray"},{"text":"Seelenstein","color":"light_purple"},{"text":" öffnet per Rechtsklick die gemeinsame Seelentruhe. Schleichen + Rechtsklick zeigt, wie es dem anderen geht.","color":"gray"}]
tellraw @a {"text":"   Hinweis: Das ist Etappe 1 – Hüter und Zwillings-Boss kommen noch. Seelenband und Kette sind in diesem Modus aus.","color":"dark_gray","italic":true}
