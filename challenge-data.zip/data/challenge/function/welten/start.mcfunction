# Rollen: 1 = Oberwelt, 2 = Nether (zufällig; alle weiteren Spieler abwechselnd)
scoreboard players set @a[tag=sb.player] sb.role 0
# gewählte Rolle (Seite 3): Wer sie eingestellt hat, bekommt seine Wunsch-Welt
execute if score #role_pick sb.cfg matches 1 run scoreboard players set @a[tag=sb.player,tag=sb.rolepick,limit=1] sb.role 1
execute if score #role_pick sb.cfg matches 2 run scoreboard players set @a[tag=sb.player,tag=sb.rolepick,limit=1] sb.role 2
execute unless entity @a[tag=sb.player,scores={sb.role=1}] run scoreboard players set @r[tag=sb.player,scores={sb.role=0}] sb.role 1
execute unless entity @a[tag=sb.player,scores={sb.role=2}] run scoreboard players set @r[tag=sb.player,scores={sb.role=0}] sb.role 2
scoreboard players set @r[tag=sb.player,scores={sb.role=0}] sb.role 1
scoreboard players set @a[tag=sb.player,scores={sb.role=0}] sb.role 2
# Seelenband und Kette sind in diesem Modus aus (getrennte Welten)
scoreboard players set #m_band sb.cfg 0
scoreboard players set #m_chain sb.cfg 0
function challenge:settings/sync
effect give @a[tag=sb.player] minecraft:resistance 15 4 true
effect give @a[tag=sb.player] minecraft:fire_resistance 30 0 true
scoreboard players set #sw_start sb 1
tellraw @a [{"text":"☯ Seelenwelten: ","color":"dark_purple","bold":true},{"text":"Ihr werdet getrennt. ","color":"gray"},{"selector":"@a[tag=sb.player,scores={sb.role=1}]","color":"aqua"},{"text":" bleibt in der Oberwelt, ","color":"gray"},{"selector":"@a[tag=sb.player,scores={sb.role=2}]","color":"red"},{"text":" lebt im Nether.","color":"gray"}]
tellraw @a [{"text":"   In jeder Welt steht ein versiegeltes ","color":"gray"},{"text":"Tor","color":"light_purple"},{"text":". Jedes Tor braucht vier Siegel. Die Rezepte stehen im Rezeptbuch – jedes braucht Zutaten aus beiden Welten:","color":"gray"}]
tellraw @a [{"text":"   ✦ Glut: ","color":"gold"},{"text":"4 Eisenbarren, 1 Kohleblock + 2 Quarz, 2 Magmablöcke","color":"gray"}]
tellraw @a [{"text":"   ✦ Tiefe: ","color":"aqua"},{"text":"4 Diamanten, 1 Obsidian + 4 Lohenruten","color":"gray"}]
tellraw @a [{"text":"   ✦ Leere: ","color":"dark_aqua"},{"text":"4 Enderperlen, 2 Amethystscherben, 1 Lapisblock + 2 Ghast-Tränen","color":"gray"}]
tellraw @a [{"text":"   ✦ Seele: ","color":"light_purple"},{"text":"2 Echoscherben, 1 Amethystblock + 2 Netheritplatten, 4 Seelensand","color":"gray"}]
tellraw @a [{"text":"   Euer ","color":"gray"},{"text":"Seelenstein","color":"light_purple"},{"text":" öffnet per Rechtsklick die gemeinsame Seelentruhe. Schleichen + Rechtsklick zeigt den Partner, euer Tor und die Siegel. Ein Siegel setzt ihr mit Rechtsklick vor eurem Tor ein.","color":"gray"}]
tellraw @a {"text":"   Sitzen alle acht Siegel, öffnen sich die Tore. Stellt euch gleichzeitig hinein – dahinter wartet der Klingenmeister. Nehmt beide einen Schild mit.","color":"dark_gray","italic":true}
