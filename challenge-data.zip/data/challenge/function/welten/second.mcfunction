# Normale Netherportale sind gesperrt: jeder bleibt in seiner Welt
execute as @a[tag=sb.player,gamemode=survival] at @s run fill ~-2 ~-2 ~-2 ~2 ~3 ~2 minecraft:air replace minecraft:nether_portal
