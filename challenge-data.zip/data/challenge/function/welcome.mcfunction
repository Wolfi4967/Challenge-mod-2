tag @s add sb.welcomed
tellraw @s {"text":" "}
tellraw @s [{"text":"⚔ Challenge-Mod","color":"gold","bold":true},{"text":" ist aktiv. Challenge zusammenstellen: Taste ","color":"gray"},{"text":"G","color":"yellow","bold":true},{"text":", Pausemenü-Button „⚔ Challenge“ oder ","color":"gray"},{"text":"/challenge","color":"yellow","click_event":{"action":"run_command","command":"/challenge"},"hover_event":{"action":"show_text","value":{"text":"Menü öffnen"}}}]
execute unless score #state sb matches 4 run function challenge:ui/open_main
