gamemode spectator @s
tellraw @s {"text":"Die Challenge läuft bereits – du schaust als Zuschauer zu.","color":"gray","italic":true}
