tag @s add sb.out
tag @s add sb.dead
gamemode spectator @s
tellraw @a [{"text":"☠ ","color":"dark_red"},{"selector":"@s","color":"red"},{"text":" ist ausgeschieden und schaut ab jetzt zu.","color":"gray"}]
execute as @a at @s run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.6 1.2
