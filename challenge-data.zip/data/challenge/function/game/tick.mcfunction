# 1) Tod? -> Challenge vorbei
execute if score #death sb.cfg matches 1 if entity @a[tag=sb.player,scores={sb.deaths=1..}] run return run function challenge:game/fail
execute if score #death sb.cfg matches 2 as @a[tag=sb.player,tag=!sb.out,scores={sb.deaths=1..}] run function challenge:game/out
execute if score #death sb.cfg matches 2 if entity @a[tag=sb.out] unless entity @a[tag=sb.player,tag=!sb.out] run return run function challenge:game/fail
# 2) Pause
execute if score #paused sb matches 1 run return run function challenge:pause/tick
# 3) Geteilter Schmerz
execute if score #m_schmerz sb.cfg matches 1 run function challenge:schmerz/tick
# 4) Timer (laeuft nur, wenn jemand online ist)
execute if entity @a[tag=sb.player,gamemode=survival] run scoreboard players add #ticks sb 1
# 5) Kette & Mob-Randomizer (jeden Tick)
execute if score #m_chain sb.cfg matches 1 run function challenge:chain/tick
execute if score #m_mobrand sb.cfg matches 1 run function challenge:mobrand/tick
# 6) Seelenband (2x pro Sekunde)
execute if score #m_band sb.cfg matches 1 if score #t sb matches 0 run function challenge:band/tick
execute if score #m_band sb.cfg matches 1 if score #t sb matches 10 run function challenge:band/tick
# 6) Sekundentakt
execute if score #t sb matches 0 run function challenge:game/second
# Schaden aus diesem Tick ist verarbeitet (Band-Schaden wird so nicht geteilt)
scoreboard players set @a sb.dmg 0
