execute in minecraft:the_end if entity @a[tag=sb.player,gamemode=survival,distance=0..] run function challenge:win/check
execute unless score #state sb matches 1 run return 0
function challenge:mutation/second
execute if score #m_mut sb.cfg matches 1 if score #m_rest sb.cfg matches 1 run function challenge:rest/second
execute if score #m_fx sb.cfg matches 1 run function challenge:fx/second
execute as @a[tag=sb.frozen] run function challenge:pause/unfreeze
execute as @a[tag=!sb.player,gamemode=!spectator] run function challenge:game/latejoin
gamemode spectator @a[tag=sb.out,gamemode=!spectator]
function challenge:goal/second
execute if score #goal sb.cfg matches 6 run function challenge:welten/second
