execute if score #state sb matches 4 run return run tellraw @s {"text":"Die Challenge ist schon deaktiviert.","color":"gray"}
scoreboard players set #state sb 4
scoreboard players set #paused sb 0
scoreboard players set #countdown sb 0
schedule clear challenge:start/countdown
execute as @a[tag=sb.frozen] run function challenge:pause/unfreeze
execute as @a run function challenge:mutation/clear_player
function challenge:mutation/reset_flags
scoreboard players set @a sb.band 0
gamemode survival @a[gamemode=adventure]
effect give @a[gamemode=spectator] minecraft:slow_falling 15 0 true
gamemode survival @a[gamemode=spectator]
function challenge:rules/off
bossbar set challenge:main visible false
scoreboard objectives setdisplay list
scoreboard objectives setdisplay below_name
tag @a remove sb.out
dialog clear @a
title @a times 10 50 20
title @a subtitle {"text":"Ab jetzt normales Minecraft – ohne Regeln.","color":"gray"}
title @a title {"text":"⛔ DEAKTIVIERT","color":"red","bold":true}
execute as @a at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 1 1
tellraw @a [{"text":"⛔ ","color":"red"},{"selector":"@s","color":"yellow"},{"text":" hat die Challenge deaktiviert. Alle Regeln sind aus. ","color":"gray"},{"text":"[↻ Wieder aktivieren]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger challenge set 17"},"hover_event":{"action":"show_text","value":{"text":"Zurück in die Lobby – danach neu starten"}}}]
