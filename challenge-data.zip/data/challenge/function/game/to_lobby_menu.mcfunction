execute if score #state sb matches 0 run return run function challenge:ui/open_main
execute if score #state sb matches 1 run return run tellraw @s {"text":"✖ Die Challenge läuft gerade – erst deaktivieren, dann neu einrichten.","color":"red"}
function challenge:game/to_lobby
function challenge:ui/open_main
