scoreboard players set #state sb 2
tag @a[tag=sb.player,scores={sb.deaths=1..}] add sb.dead
gamemode spectator @a
execute as @a[tag=sb.player] run function challenge:mutation/clear_player
bossbar set challenge:main name {"text":"✖ CHALLENGE GESCHEITERT ✖","color":"dark_red","bold":true}
bossbar set challenge:main color red
title @a times 10 100 40
title @a subtitle [{"selector":"@a[tag=sb.dead]","color":"red"},{"text":" ist gestorben …","color":"gray"}]
title @a title {"text":"GESCHEITERT","color":"dark_red","bold":true}
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.7 0.8
tellraw @a {"text":" "}
tellraw @a [{"text":"☠ ","color":"dark_red"},{"selector":"@a[tag=sb.dead]","color":"red"},{"text":" ist gestorben – die Challenge ist vorbei.","color":"gray"}]
function challenge:stats/print
tellraw @a [{"text":"↻ Neuer Versuch: ","color":"yellow","bold":true},{"text":"Neue Welt erstellen und das Datapack wieder hinzufügen – frischer Seed, frisches Glück.","color":"gray"}]
