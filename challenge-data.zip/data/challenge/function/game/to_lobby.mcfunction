scoreboard players set #state sb 0
scoreboard players set #paused sb 0
scoreboard players set #countdown sb 0
execute as @a[tag=sb.frozen] run function challenge:pause/unfreeze
execute as @a run function challenge:mutation/clear_player
function challenge:mutation/reset_flags
tag @a remove sb.dead
tag @a remove sb.out
scoreboard objectives setdisplay list sb.hp
scoreboard objectives setdisplay below_name sb.hp
effect give @a[gamemode=spectator] minecraft:slow_falling 15 0 true
gamemode adventure @a[gamemode=spectator]
gamemode adventure @a[gamemode=survival]
bossbar set challenge:main visible true
execute as @a at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1
tellraw @a [{"text":"↻ ","color":"green"},{"selector":"@s","color":"yellow"},{"text":" hat die Challenge wieder aktiviert – ihr seid in der Lobby.","color":"gray"}]
tellraw @a {"text":"   Achtung: Beim nächsten Start werden Inventar, Level und Advancements zurückgesetzt.","color":"gold"}
