# Seelenwelten: Wer die Rollen einstellt, wählt für sich selbst
execute unless score #role_pick sb.cfg matches 0..2 run scoreboard players set #role_pick sb.cfg 0
tag @a remove sb.rolepick
tag @s add sb.rolepick
