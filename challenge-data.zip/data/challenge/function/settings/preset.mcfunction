scoreboard players operation #p sb = @s challenge
scoreboard players operation #p sb %= #10 sb.const
execute if score #p sb matches 1 run scoreboard players set #band_max sb.cfg 64
execute if score #p sb matches 1 run scoreboard players set #diff sb.cfg 2
execute if score #p sb matches 1 run scoreboard players set #regen sb.cfg 1
execute if score #p sb matches 2 run scoreboard players set #band_max sb.cfg 40
execute if score #p sb matches 2 run scoreboard players set #diff sb.cfg 3
execute if score #p sb matches 2 run scoreboard players set #regen sb.cfg 1
execute if score #p sb matches 3 run scoreboard players set #band_max sb.cfg 24
execute if score #p sb matches 3 run scoreboard players set #diff sb.cfg 3
execute if score #p sb matches 3 run scoreboard players set #regen sb.cfg 0
function challenge:settings/sync
