function challenge:settings/sync
function challenge:rules/common
execute if score #diff sb.cfg matches 1 run difficulty easy
execute if score #diff sb.cfg matches 2 run difficulty normal
execute if score #diff sb.cfg matches 3 run difficulty hard
execute if score #regen sb.cfg matches 1 run function challenge:rules/regen_on
execute if score #regen sb.cfg matches 0 run function challenge:rules/regen_off
# Ultra Hardcore: immer Schwer und keine natürliche Regeneration
execute if score #m_uhc sb.cfg matches 1 run difficulty hard
execute if score #m_uhc sb.cfg matches 1 run function challenge:rules/regen_off
