tellraw @a [{"text":"⚙ ","color":"gold"},{"selector":"@s","color":"yellow"},{"text":" hat die Einstellungen geändert:","color":"gray"}]
execute if score #diff sb.cfg matches 1 run tellraw @a [{"text":"   Schwierigkeit ","color":"gray"},{"text":"Leicht","color":"green"},{"text":" • Seelenband ","color":"gray"},{"score":{"name":"#band_max","objective":"sb.cfg"},"color":"white"},{"text":" Blöcke","color":"white"}]
execute if score #diff sb.cfg matches 2 run tellraw @a [{"text":"   Schwierigkeit ","color":"gray"},{"text":"Normal","color":"yellow"},{"text":" • Seelenband ","color":"gray"},{"score":{"name":"#band_max","objective":"sb.cfg"},"color":"white"},{"text":" Blöcke","color":"white"}]
execute if score #diff sb.cfg matches 3 run tellraw @a [{"text":"   Schwierigkeit ","color":"gray"},{"text":"Schwer","color":"red"},{"text":" • Seelenband ","color":"gray"},{"score":{"name":"#band_max","objective":"sb.cfg"},"color":"white"},{"text":" Blöcke","color":"white"}]
execute if score #regen sb.cfg matches 1 run tellraw @a {"text":"   Natürliche Regeneration: an","color":"gray"}
execute if score #regen sb.cfg matches 0 run tellraw @a {"text":"   Natürliche Regeneration: AUS","color":"red"}
execute if score #m_uhc sb.cfg matches 1 run tellraw @a {"text":"   ☠ ULTRA HARDCORE: Schwer, keine natürliche Regeneration","color":"dark_red","bold":true}
execute if score #m_chain sb.cfg matches 1 run tellraw @a [{"text":"   ⚯ Kette: ","color":"gray"},{"score":{"name":"#chain_len","objective":"sb.cfg"},"color":"white"},{"text":" Blöcke","color":"white"}]
execute if score #m_mobrand sb.cfg matches 1 run tellraw @a {"text":"   ⚄ Mob-Randomizer: an","color":"gray"}
execute if score #m_brand sb.cfg matches 1 run tellraw @a {"text":"   ▣ Block-Randomizer: an","color":"gray"}
execute if score #m_cshift sb.cfg matches 1 run tellraw @a [{"text":"   ⇅ Chunk-Versatz: an (bis ","color":"gray"},{"score":{"name":"#cshift_max","objective":"sb.cfg"},"color":"white"},{"text":" Blöcke)","color":"gray"}]
execute if score #m_cbiome sb.cfg matches 1 run tellraw @a {"text":"   ▦ Zufalls-Biom pro Chunk: an","color":"gray"}
execute if score #m_mobdrop sb.cfg matches 1 run tellraw @a {"text":"   ☠ Mob-Drop-Randomizer: an","color":"gray"}
execute if score #m_chest sb.cfg matches 1 run tellraw @a {"text":"   ▤ Truhen- & Angel-Randomizer: an","color":"gray"}
execute if score #m_craft sb.cfg matches 1 run tellraw @a {"text":"   ⚒ Crafting-Randomizer: an","color":"gray"}
execute if score #goal sb.cfg matches 1 run tellraw @a [{"text":"   ✪ Ziel: ","color":"gray"},{"text":"Enderdrache","color":"light_purple"}]
execute if score #goal sb.cfg matches 2 run tellraw @a [{"text":"   ✪ Ziel: ","color":"gray"},{"text":"Wither","color":"dark_gray"}]
execute if score #goal sb.cfg matches 3 run tellraw @a [{"text":"   ✪ Ziel: ","color":"gray"},{"text":"Wärter","color":"dark_aqua"}]
execute if score #goal sb.cfg matches 4 run tellraw @a [{"text":"   ✪ Ziel: ","color":"gray"},{"text":"Ältester Wächter","color":"aqua"}]
execute if score #goal sb.cfg matches 5 run tellraw @a [{"text":"   ✪ Ziel: ","color":"gray"},{"text":"Alle vier Bosse","color":"gold"}]
execute if score #goal sb.cfg matches 6 run tellraw @a [{"text":"   ✪ Ziel: ","color":"gray"},{"text":"Seelenwelten: Die Rissblüte","color":"dark_purple"}]
execute if score #death sb.cfg matches 1 run tellraw @a [{"text":"   ☠ Tod: ","color":"gray"},{"text":"Einer stirbt → alle verlieren","color":"red"}]
execute if score #death sb.cfg matches 2 run tellraw @a [{"text":"   ☠ Tod: ","color":"gray"},{"text":"Wer stirbt, scheidet aus","color":"red"}]
execute if score #m_fx sb.cfg matches 1 run tellraw @a {"text":"   ⚡ Zufallseffekte alle 5 Minuten: an","color":"gray"}
execute if score #m_mut sb.cfg matches 1 if score #m_perm sb.cfg matches 1 run tellraw @a {"text":"   Mutationen: dauerhaft (stapeln sich)","color":"light_purple"}
execute if score #m_mut sb.cfg matches 1 if score #m_perm sb.cfg matches 0 run tellraw @a {"text":"   Mutationen: wechselnd (neue ersetzt alte)","color":"gray"}
