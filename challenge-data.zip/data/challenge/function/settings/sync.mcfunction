execute if score #band_max sb.cfg matches ..7 run scoreboard players set #band_max sb.cfg 8
execute if score #band_max sb.cfg matches 201.. run scoreboard players set #band_max sb.cfg 200
scoreboard players set #3 sb.const 3
scoreboard players set #4 sb.const 4
execute unless score #chain_len sb.cfg matches 3..20 run scoreboard players set #chain_len sb.cfg 6
# effektive Seelenband-Distanz: normal die eingestellte, mit Kette = Kettenlänge + 6 (Kette überdehnt)
scoreboard players operation #bmax sb.cfg = #band_max sb.cfg
execute if score #m_chain sb.cfg matches 1 run scoreboard players operation #bmax sb.cfg = #chain_len sb.cfg
execute if score #m_chain sb.cfg matches 1 run scoreboard players add #bmax sb.cfg 6
scoreboard players operation #band_warn sb.cfg = #bmax sb.cfg
scoreboard players operation #band_warn sb.cfg *= #3 sb.const
scoreboard players operation #band_warn sb.cfg /= #4 sb.const
execute if score #m_chain sb.cfg matches 1 run scoreboard players operation #band_warn sb.cfg = #chain_len sb.cfg
execute if score #m_chain sb.cfg matches 1 run scoreboard players add #band_warn sb.cfg 3
execute store result storage challenge:cfg max int 1 run scoreboard players get #bmax sb.cfg
execute store result storage challenge:cfg warn int 1 run scoreboard players get #band_warn sb.cfg
execute store result storage challenge:cfg clen int 1 run scoreboard players get #chain_len sb.cfg
scoreboard players operation #clen2 sb.cfg = #chain_len sb.cfg
scoreboard players add #clen2 sb.cfg 3
execute store result storage challenge:cfg clen2 int 1 run scoreboard players get #clen2 sb.cfg
scoreboard players set #preset sb.cfg 0
execute if score #band_max sb.cfg matches 64 if score #diff sb.cfg matches 2 if score #regen sb.cfg matches 1 run scoreboard players set #preset sb.cfg 1
execute if score #band_max sb.cfg matches 40 if score #diff sb.cfg matches 3 if score #regen sb.cfg matches 1 run scoreboard players set #preset sb.cfg 2
execute if score #band_max sb.cfg matches 24 if score #diff sb.cfg matches 3 if score #regen sb.cfg matches 0 run scoreboard players set #preset sb.cfg 3
