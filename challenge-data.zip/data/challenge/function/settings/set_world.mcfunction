execute unless score #state sb matches 0 run return run function challenge:settings/locked
execute if score #countdown sb matches 1.. run return run function challenge:settings/locked
$scoreboard players set #cshift_max sb.cfg $(cmax)
$scoreboard players set #m_cshift sb.cfg $(cshift)
$scoreboard players set #m_cbiome sb.cfg $(cbiome)
$scoreboard players set #m_mobdrop sb.cfg $(mobdrop)
$scoreboard players set #m_chest sb.cfg $(chest)
$scoreboard players set #m_craft sb.cfg $(craft)
function challenge:settings/clamp
function challenge:settings/sync
function challenge:settings/announce
execute as @a at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.4
scoreboard players set #saved sb 1
function challenge:ui/open_world
