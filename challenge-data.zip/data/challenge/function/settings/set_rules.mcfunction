execute unless score #state sb matches 0 run return run function challenge:settings/locked
execute if score #countdown sb matches 1.. run return run function challenge:settings/locked
$scoreboard players set #band_max sb.cfg $(dist)
$scoreboard players set #diff sb.cfg $(diff)
$scoreboard players set #regen sb.cfg $(regen)
$scoreboard players set #m_uhc sb.cfg $(uhc)
$scoreboard players set #m_schmerz sb.cfg $(schmerz)
$scoreboard players set #m_band sb.cfg $(band)
$scoreboard players set #m_rest sb.cfg $(rest)
function challenge:settings/clamp
function challenge:settings/sync
function challenge:settings/announce
execute as @a at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.4
function challenge:ui/open_chaos
