execute unless score #state sb matches 0 run return run function challenge:settings/locked
execute if score #countdown sb matches 1.. run return run function challenge:settings/locked
$scoreboard players set #chain_len sb.cfg $(clen)
$scoreboard players set #m_chain sb.cfg $(chain)
$scoreboard players set #m_mut sb.cfg $(mut)
$scoreboard players set #m_perm sb.cfg $(perm)
$scoreboard players set #m_mobrand sb.cfg $(mobrand)
$scoreboard players set #m_brand sb.cfg $(brand)
$scoreboard players set #m_fx sb.cfg $(fx)
function challenge:settings/clamp
function challenge:settings/sync
function challenge:settings/announce
execute as @a at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.4
scoreboard players set #saved sb 1
function challenge:ui/open_chaos
