execute unless score #state sb matches 0 run return run function challenge:settings/locked
execute if score #countdown sb matches 1.. run return run function challenge:settings/locked
$scoreboard players set #goal sb.cfg $(goal)
$scoreboard players set #death sb.cfg $(death)
$scoreboard players set #role_pick sb.cfg $(role)
function challenge:settings/rolepick
function challenge:settings/clamp
function challenge:settings/sync
function challenge:settings/announce
execute as @a at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.6 1.4
scoreboard players set #saved sb 1
function challenge:ui/open_goal
