scoreboard players set #lockmsg sb 1
tellraw @s {"text":"✖ Einstellungen können nur vor dem Start geändert werden.","color":"red"}
function challenge:ui/open_main
