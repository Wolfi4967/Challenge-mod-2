execute unless score #state sb matches 0 run return run function challenge:settings/locked
execute if score #countdown sb matches 1.. run return run function challenge:settings/locked
function challenge:settings/preset
function challenge:settings/announce
scoreboard players set #saved sb 1
function challenge:ui/open_settings
