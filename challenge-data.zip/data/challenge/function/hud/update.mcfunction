function challenge:hud/time
scoreboard players set #fx_left sb 300
scoreboard players operation #fx_left sb -= #fx_t sb
execute as @a run function challenge:hud/player
