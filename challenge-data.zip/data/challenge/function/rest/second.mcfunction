scoreboard players add @a sb.sneak 0
scoreboard players set #rest_ok sb 1
execute unless score #count sb.mut matches 1.. run scoreboard players set #rest_ok sb 0
execute store result score #n sb if entity @a[tag=sb.player,gamemode=survival]
execute if score #n sb matches ..1 run scoreboard players set #rest_ok sb 0
execute if score #rest_ok sb matches 1 if entity @a[tag=sb.player,gamemode=survival,scores={sb.sneak=..9}] run scoreboard players set #rest_ok sb 0
execute if score #rest_ok sb matches 1 as @a[tag=sb.player,gamemode=survival] at @s unless function challenge:rest/near_fire run scoreboard players set #rest_ok sb 0
execute if score #rest_ok sb matches 1 if entity @a[tag=sb.player,gamemode=survival,level=..2] run scoreboard players set #rest_ok sb 2
scoreboard players set @a sb.sneak 0
execute unless score #rest_ok sb matches 1 run scoreboard players set #rest sb 0
execute if score #rest_ok sb matches 1 run scoreboard players add #rest sb 1
execute if score #rest_ok sb matches 1 as @a[tag=sb.player,gamemode=survival] at @s run playsound minecraft:block.campfire.crackle master @s ~ ~ ~ 1 1
execute if score #rest_ok sb matches 1 as @a[tag=sb.player,gamemode=survival] at @s run particle minecraft:campfire_cosy_smoke ~ ~1 ~ 0.3 0.4 0.3 0.01 2 normal @a
execute if score #rest sb matches 5.. run function challenge:rest/complete
