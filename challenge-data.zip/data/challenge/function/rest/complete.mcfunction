scoreboard players set #rest sb 0
scoreboard players set #rest_ok sb 0
xp add @a[tag=sb.player,gamemode=survival] -3 levels
scoreboard players add #rests sb 1
execute unless score #m_uhc sb.cfg matches 1 run effect give @a[tag=sb.player,gamemode=survival] minecraft:regeneration 8 1 true
execute as @a at @s run playsound minecraft:block.respawn_anchor.charge master @s ~ ~ ~ 1 1
execute if score #m_perm sb.cfg matches 0 run tellraw @a [{"text":"⛺ ","color":"gold"},{"text":"Ihr habt am Lagerfeuer gerastet. Die Seelen gewähren euch eine neue Mutation …","color":"gold"}]
execute if score #m_perm sb.cfg matches 0 run return run function challenge:mutation/new
function challenge:mutation/remove_newest
