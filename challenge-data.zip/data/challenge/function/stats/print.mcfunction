function challenge:hud/time
scoreboard players operation #sh sb = #schmerz_total sb
scoreboard players operation #sh sb /= #20 sb.const
tellraw @a {"text":"━━━━━━━━ STATISTIK ━━━━━━━━","color":"gold","bold":true}
tellraw @a [{"text":" ⏱ Zeit: ","color":"gray"},{"score":{"name":"#h","objective":"sb"},"color":"white","bold":false},{"text":":","color":"white","bold":false},{"score":{"name":"#m10","objective":"sb"},"color":"white","bold":false},{"score":{"name":"#m1","objective":"sb"},"color":"white","bold":false},{"text":":","color":"white","bold":false},{"score":{"name":"#s10","objective":"sb"},"color":"white","bold":false},{"score":{"name":"#s1","objective":"sb"},"color":"white","bold":false}]
tellraw @a [{"text":" ★ Advancements: ","color":"gray"},{"score":{"name":"#adv","objective":"sb"},"color":"white"}]
tellraw @a [{"text":" ⚗ Mutationen: ","color":"gray"},{"score":{"name":"#rerolls","objective":"sb"},"color":"white"}]
execute if score #m_perm sb.cfg matches 1 run tellraw @a [{"text":" ♾ Davon am Ende aktiv: ","color":"gray"},{"score":{"name":"#count","objective":"sb.mut"},"color":"white"}]
tellraw @a [{"text":" ❤ Geteilter Schmerz: ","color":"gray"},{"score":{"name":"#sh","objective":"sb"},"color":"white"},{"text":" Herzen","color":"white"}]
tellraw @a [{"text":" ⛺ Lagerfeuer-Rasten: ","color":"gray"},{"score":{"name":"#rests","objective":"sb"},"color":"white"}]
execute if score #preset sb.cfg matches 1 run tellraw @a [{"text":" ⛓ Modus: ","color":"gray"},{"text":"Entspannt","color":"light_purple"}]
execute if score #preset sb.cfg matches 2 run tellraw @a [{"text":" ⛓ Modus: ","color":"gray"},{"text":"Standard","color":"light_purple"}]
execute if score #preset sb.cfg matches 3 run tellraw @a [{"text":" ⛓ Modus: ","color":"gray"},{"text":"Wahnsinn","color":"light_purple"}]
execute if score #preset sb.cfg matches 0 if score #diff sb.cfg matches 1 run tellraw @a [{"text":" ⛓ Modus: ","color":"gray"},{"text":"Eigene","color":"light_purple"},{"text":" (Leicht, ","color":"gray"},{"score":{"name":"#band_max","objective":"sb.cfg"},"color":"gray"},{"text":" Blöcke)","color":"gray"}]
execute if score #preset sb.cfg matches 0 if score #diff sb.cfg matches 2 run tellraw @a [{"text":" ⛓ Modus: ","color":"gray"},{"text":"Eigene","color":"light_purple"},{"text":" (Normal, ","color":"gray"},{"score":{"name":"#band_max","objective":"sb.cfg"},"color":"gray"},{"text":" Blöcke)","color":"gray"}]
execute if score #preset sb.cfg matches 0 if score #diff sb.cfg matches 3 run tellraw @a [{"text":" ⛓ Modus: ","color":"gray"},{"text":"Eigene","color":"light_purple"},{"text":" (Schwer, ","color":"gray"},{"score":{"name":"#band_max","objective":"sb.cfg"},"color":"gray"},{"text":" Blöcke)","color":"gray"}]
tellraw @a {"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"gold"}
