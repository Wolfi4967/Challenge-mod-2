bossbar set challenge:main players @a
execute if score #state sb matches 4 run bossbar set challenge:main visible false
execute unless score #state sb matches 4 run bossbar set challenge:main visible true
execute if score #state sb matches 0 run function challenge:lobby/second
execute if score #state sb matches 2 run gamemode spectator @a[gamemode=!spectator]
execute as @a[tag=!sb.welcomed] run function challenge:welcome
execute as @a unless score @s sb.bvar matches 1..3 run scoreboard players operation @s sb.bvar = #bvar sb
