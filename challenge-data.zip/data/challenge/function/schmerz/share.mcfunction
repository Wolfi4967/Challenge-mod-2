scoreboard players operation #schmerz_total sb += @s sb.pending
execute store result storage challenge:tmp amount float 0.1 run scoreboard players get @s sb.pending
tag @s add sb.src
execute as @a[tag=sb.player,gamemode=survival,tag=!sb.src] run function challenge:schmerz/apply with storage challenge:tmp
tag @s remove sb.src
