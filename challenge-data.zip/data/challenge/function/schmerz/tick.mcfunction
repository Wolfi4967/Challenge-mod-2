execute as @a[tag=sb.player,gamemode=survival] run scoreboard players operation @s sb.pending = @s sb.dmg
scoreboard players set @a sb.dmg 0
execute as @a[tag=sb.player,gamemode=survival,scores={sb.pending=1..}] run function challenge:schmerz/share
scoreboard players set @a sb.pending 0
# Schaden, der gerade geteilt wurde, darf nicht zurueckgeteilt werden
scoreboard players set @a sb.dmg 0
