$damage @s $(amount) challenge:schmerz
