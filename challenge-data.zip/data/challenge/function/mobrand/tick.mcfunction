execute as @e[type=#challenge:rand_monster,tag=!sb.seen] at @s run function challenge:mobrand/monster
execute as @e[type=#challenge:rand_animal,tag=!sb.seen] at @s run function challenge:mobrand/animal
