summon minecraft:blaze ~ ~ ~ {Tags:["sb.seen"]}
