summon minecraft:witch ~ ~ ~ {Tags:["sb.seen"]}
