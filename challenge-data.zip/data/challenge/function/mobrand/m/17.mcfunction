summon minecraft:pillager ~ ~ ~ {Tags:["sb.seen"]}
