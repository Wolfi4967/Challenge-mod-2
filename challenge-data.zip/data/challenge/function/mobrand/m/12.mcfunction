summon minecraft:slime ~ ~ ~ {Tags:["sb.seen"]}
