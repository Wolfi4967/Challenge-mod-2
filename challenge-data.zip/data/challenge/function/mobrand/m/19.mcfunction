summon minecraft:evoker ~ ~ ~ {Tags:["sb.seen"]}
