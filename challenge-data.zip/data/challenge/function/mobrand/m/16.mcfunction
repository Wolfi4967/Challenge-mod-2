summon minecraft:phantom ~ ~ ~ {Tags:["sb.seen"]}
