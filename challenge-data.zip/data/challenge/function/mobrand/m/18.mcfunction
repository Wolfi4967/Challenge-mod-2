summon minecraft:vindicator ~ ~ ~ {Tags:["sb.seen"]}
