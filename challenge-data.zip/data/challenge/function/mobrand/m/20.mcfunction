summon minecraft:silverfish ~ ~ ~ {Tags:["sb.seen"]}
