summon minecraft:zoglin ~ ~ ~ {Tags:["sb.seen"]}
