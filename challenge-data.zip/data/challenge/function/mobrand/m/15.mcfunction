summon minecraft:wither_skeleton ~ ~ ~ {Tags:["sb.seen"]}
