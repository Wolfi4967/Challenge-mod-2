summon minecraft:stray ~ ~ ~ {Tags:["sb.seen"]}
