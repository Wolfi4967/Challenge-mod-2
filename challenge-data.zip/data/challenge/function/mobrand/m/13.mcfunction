summon minecraft:magma_cube ~ ~ ~ {Tags:["sb.seen"]}
