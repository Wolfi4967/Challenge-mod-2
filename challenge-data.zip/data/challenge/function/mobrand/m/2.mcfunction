summon minecraft:husk ~ ~ ~ {Tags:["sb.seen"]}
