summon minecraft:drowned ~ ~ ~ {Tags:["sb.seen"]}
