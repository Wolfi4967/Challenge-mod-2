summon minecraft:zombified_piglin ~ ~ ~ {Tags:["sb.seen"]}
