summon minecraft:enderman ~ ~ ~ {Tags:["sb.seen"]}
