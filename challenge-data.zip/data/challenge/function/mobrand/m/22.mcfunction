summon minecraft:breeze ~ ~ ~ {Tags:["sb.seen"]}
