summon minecraft:piglin ~ ~ ~ {Tags:["sb.seen"]}
