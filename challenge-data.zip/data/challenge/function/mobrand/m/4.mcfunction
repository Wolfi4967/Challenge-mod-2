summon minecraft:skeleton ~ ~ ~ {Tags:["sb.seen"]}
