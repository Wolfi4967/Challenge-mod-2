summon minecraft:spider ~ ~ ~ {Tags:["sb.seen"]}
