summon minecraft:ghast ~ ~ ~ {Tags:["sb.seen"]}
