summon minecraft:creeper ~ ~ ~ {Tags:["sb.seen"]}
