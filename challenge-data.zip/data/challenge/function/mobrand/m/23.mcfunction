summon minecraft:hoglin ~ ~ ~ {Tags:["sb.seen"]}
