summon minecraft:bogged ~ ~ ~ {Tags:["sb.seen"]}
