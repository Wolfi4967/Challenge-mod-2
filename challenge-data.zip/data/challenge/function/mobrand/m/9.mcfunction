summon minecraft:cave_spider ~ ~ ~ {Tags:["sb.seen"]}
