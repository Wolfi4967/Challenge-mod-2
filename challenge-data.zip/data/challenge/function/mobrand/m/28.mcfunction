summon minecraft:zombie_villager ~ ~ ~ {Tags:["sb.seen"]}
