summon minecraft:zombie ~ ~ ~ {Tags:["sb.seen"]}
