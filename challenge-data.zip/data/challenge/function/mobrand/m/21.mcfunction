summon minecraft:endermite ~ ~ ~ {Tags:["sb.seen"]}
