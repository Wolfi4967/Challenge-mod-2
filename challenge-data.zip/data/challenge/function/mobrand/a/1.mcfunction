summon minecraft:cow ~ ~ ~ {Tags:["sb.seen"]}
