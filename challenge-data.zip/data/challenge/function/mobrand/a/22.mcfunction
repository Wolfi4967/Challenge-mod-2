summon minecraft:parrot ~ ~ ~ {Tags:["sb.seen"]}
