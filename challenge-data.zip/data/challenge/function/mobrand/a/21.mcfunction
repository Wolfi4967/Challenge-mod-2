summon minecraft:ocelot ~ ~ ~ {Tags:["sb.seen"]}
