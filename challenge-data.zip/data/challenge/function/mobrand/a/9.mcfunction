summon minecraft:goat ~ ~ ~ {Tags:["sb.seen"]}
