summon minecraft:armadillo ~ ~ ~ {Tags:["sb.seen"]}
