summon minecraft:mooshroom ~ ~ ~ {Tags:["sb.seen"]}
