summon minecraft:cat ~ ~ ~ {Tags:["sb.seen"]}
