summon minecraft:pig ~ ~ ~ {Tags:["sb.seen"]}
