summon minecraft:bee ~ ~ ~ {Tags:["sb.seen"]}
