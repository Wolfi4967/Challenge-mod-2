summon minecraft:wolf ~ ~ ~ {Tags:["sb.seen"]}
