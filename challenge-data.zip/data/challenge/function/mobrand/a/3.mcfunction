summon minecraft:sheep ~ ~ ~ {Tags:["sb.seen"]}
