summon minecraft:fox ~ ~ ~ {Tags:["sb.seen"]}
