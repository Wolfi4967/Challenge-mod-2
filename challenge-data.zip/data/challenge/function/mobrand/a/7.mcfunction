summon minecraft:donkey ~ ~ ~ {Tags:["sb.seen"]}
