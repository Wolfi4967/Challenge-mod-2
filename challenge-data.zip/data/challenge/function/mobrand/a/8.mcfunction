summon minecraft:llama ~ ~ ~ {Tags:["sb.seen"]}
