summon minecraft:horse ~ ~ ~ {Tags:["sb.seen"]}
