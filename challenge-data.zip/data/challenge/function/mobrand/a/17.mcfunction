summon minecraft:camel ~ ~ ~ {Tags:["sb.seen"]}
