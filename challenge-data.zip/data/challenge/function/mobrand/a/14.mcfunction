summon minecraft:polar_bear ~ ~ ~ {Tags:["sb.seen"]}
