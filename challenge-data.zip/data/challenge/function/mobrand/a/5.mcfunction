summon minecraft:rabbit ~ ~ ~ {Tags:["sb.seen"]}
