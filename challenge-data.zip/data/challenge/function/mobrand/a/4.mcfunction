summon minecraft:chicken ~ ~ ~ {Tags:["sb.seen"]}
