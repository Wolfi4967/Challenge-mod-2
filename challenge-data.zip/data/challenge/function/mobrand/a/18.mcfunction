summon minecraft:turtle ~ ~ ~ {Tags:["sb.seen"]}
