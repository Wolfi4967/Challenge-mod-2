summon minecraft:frog ~ ~ ~ {Tags:["sb.seen"]}
