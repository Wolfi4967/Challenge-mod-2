summon minecraft:panda ~ ~ ~ {Tags:["sb.seen"]}
