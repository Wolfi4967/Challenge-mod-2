tag @s add sb.seen
# benannte und gezähmte Tiere bleiben, wie sie sind
execute if data entity @s CustomName run return 0
execute if data entity @s Owner run return 0
# Babys bleiben, damit Züchten weiter funktioniert
execute store result score #age sb run data get entity @s Age
execute if score #age sb matches ..-1 run return 0
execute store result score #mr sb run random value 1..22
execute if score #mr sb matches 1 run function challenge:mobrand/a/1
execute if score #mr sb matches 2 run function challenge:mobrand/a/2
execute if score #mr sb matches 3 run function challenge:mobrand/a/3
execute if score #mr sb matches 4 run function challenge:mobrand/a/4
execute if score #mr sb matches 5 run function challenge:mobrand/a/5
execute if score #mr sb matches 6 run function challenge:mobrand/a/6
execute if score #mr sb matches 7 run function challenge:mobrand/a/7
execute if score #mr sb matches 8 run function challenge:mobrand/a/8
execute if score #mr sb matches 9 run function challenge:mobrand/a/9
execute if score #mr sb matches 10 run function challenge:mobrand/a/10
execute if score #mr sb matches 11 run function challenge:mobrand/a/11
execute if score #mr sb matches 12 run function challenge:mobrand/a/12
execute if score #mr sb matches 13 run function challenge:mobrand/a/13
execute if score #mr sb matches 14 run function challenge:mobrand/a/14
execute if score #mr sb matches 15 run function challenge:mobrand/a/15
execute if score #mr sb matches 16 run function challenge:mobrand/a/16
execute if score #mr sb matches 17 run function challenge:mobrand/a/17
execute if score #mr sb matches 18 run function challenge:mobrand/a/18
execute if score #mr sb matches 19 run function challenge:mobrand/a/19
execute if score #mr sb matches 20 run function challenge:mobrand/a/20
execute if score #mr sb matches 21 run function challenge:mobrand/a/21
execute if score #mr sb matches 22 run function challenge:mobrand/a/22
tp @s ~ -600 ~
kill @s
