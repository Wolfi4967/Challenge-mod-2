tag @s add sb.seen
# benannte und gezähmte Tiere bleiben, wie sie sind
execute if data entity @s CustomName run return 0
execute if data entity @s Owner run return 0
execute store result score #mr sb run random value 1..28
execute if score #mr sb matches 1 run function challenge:mobrand/m/1
execute if score #mr sb matches 2 run function challenge:mobrand/m/2
execute if score #mr sb matches 3 run function challenge:mobrand/m/3
execute if score #mr sb matches 4 run function challenge:mobrand/m/4
execute if score #mr sb matches 5 run function challenge:mobrand/m/5
execute if score #mr sb matches 6 run function challenge:mobrand/m/6
execute if score #mr sb matches 7 run function challenge:mobrand/m/7
execute if score #mr sb matches 8 run function challenge:mobrand/m/8
execute if score #mr sb matches 9 run function challenge:mobrand/m/9
execute if score #mr sb matches 10 run function challenge:mobrand/m/10
execute if score #mr sb matches 11 run function challenge:mobrand/m/11
execute if score #mr sb matches 12 run function challenge:mobrand/m/12
execute if score #mr sb matches 13 run function challenge:mobrand/m/13
execute if score #mr sb matches 14 run function challenge:mobrand/m/14
execute if score #mr sb matches 15 run function challenge:mobrand/m/15
execute if score #mr sb matches 16 run function challenge:mobrand/m/16
execute if score #mr sb matches 17 run function challenge:mobrand/m/17
execute if score #mr sb matches 18 run function challenge:mobrand/m/18
execute if score #mr sb matches 19 run function challenge:mobrand/m/19
execute if score #mr sb matches 20 run function challenge:mobrand/m/20
execute if score #mr sb matches 21 run function challenge:mobrand/m/21
execute if score #mr sb matches 22 run function challenge:mobrand/m/22
execute if score #mr sb matches 23 run function challenge:mobrand/m/23
execute if score #mr sb matches 24 run function challenge:mobrand/m/24
execute if score #mr sb matches 25 run function challenge:mobrand/m/25
execute if score #mr sb matches 26 run function challenge:mobrand/m/26
execute if score #mr sb matches 27 run function challenge:mobrand/m/27
execute if score #mr sb matches 28 run function challenge:mobrand/m/28
tp @s ~ -600 ~
kill @s
