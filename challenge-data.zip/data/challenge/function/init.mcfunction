scoreboard players set #init sb 1
# neue Welten: Challenge AUS, bis jemand /challenge einrichtet
scoreboard players set #state sb 4
scoreboard players set #paused sb 0
scoreboard players set #countdown sb 0
scoreboard players set #ticks sb 0
scoreboard players set #t sb 0
scoreboard players set #diff sb.cfg 3
scoreboard players set #regen sb.cfg 1
scoreboard players set #band_max sb.cfg 40
scoreboard players set #m_schmerz sb.cfg 1
scoreboard players set #m_band sb.cfg 1
scoreboard players set #m_mut sb.cfg 1
scoreboard players set #m_rest sb.cfg 1
scoreboard players set #m_perm sb.cfg 0
scoreboard players set #m_brand sb.cfg 0
scoreboard players set #goal sb.cfg 1
scoreboard players set #death sb.cfg 1
function challenge:mutation/reset_flags
scoreboard players set #adv sb 0
scoreboard players set #rerolls sb 0
function challenge:settings/sync
