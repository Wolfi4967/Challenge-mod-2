scoreboard players remove #countdown sb 1
execute if score #countdown sb matches 3 run title @a title {"text":"3","color":"green","bold":true}
execute if score #countdown sb matches 2 run title @a title {"text":"2","color":"yellow","bold":true}
execute if score #countdown sb matches 1 run title @a title {"text":"1","color":"red","bold":true}
execute if score #countdown sb matches 1.. as @a at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1
execute if score #countdown sb matches 1.. run schedule function challenge:start/countdown 20t
execute if score #countdown sb matches 0 run function challenge:start/go
