gamemode survival @s
clear @s
effect clear @s
xp set @s 0 levels
xp set @s 0 points
advancement revoke @s everything
function challenge:mutation/clear_player
attribute @s minecraft:movement_speed modifier remove challenge:pause
attribute @s minecraft:jump_strength modifier remove challenge:pause
scoreboard players set @s sb.mut -1
scoreboard players set @s sb.deaths 0
scoreboard players set @s sb.dmg 0
scoreboard players set @s sb.pending 0
scoreboard players set @s sb.dimt 0
scoreboard players set @s sb.band 0
scoreboard players set @s sb.sneak 0
scoreboard players operation @s sb.bvar = #bvar sb
scoreboard players set @s sb.follow 0
scoreboard players set @s sb.kwither 0
scoreboard players set @s sb.kwarden 0
scoreboard players set @s sb.kelder 0
effect give @s minecraft:instant_health 1 5 true
effect give @s minecraft:saturation 1 20 true
