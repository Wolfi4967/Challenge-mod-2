scoreboard players set #state sb 1
scoreboard players set #paused sb 0
scoreboard players set #ticks sb 0
scoreboard players set #rerolls sb 0
scoreboard players set #schmerz_total sb 0
scoreboard players set #rests sb 0
scoreboard players set #rest sb 0
scoreboard players set #rest_ok sb 0
scoreboard players set #adv sb 0
scoreboard players set #adv_last sb 0
function challenge:mutation/reset_flags
tag @a remove sb.player
tag @a remove sb.dead
tag @a remove sb.frozen
tag @a remove sb.out
tag @a[gamemode=!spectator] add sb.player
scoreboard players set #won_dragon sb 0
scoreboard players set #won_wither sb 0
scoreboard players set #won_warden sb 0
scoreboard players set #won_elder sb 0
scoreboard objectives setdisplay list sb.hp
scoreboard objectives setdisplay below_name sb.hp
function challenge:settings/apply
execute store result score #bvar sb run random value 1..3
scoreboard players set #fx_t sb 0
time set day
weather clear
execute as @a[tag=sb.player] run function challenge:start/reset_player
execute if score #goal sb.cfg matches 6 run function challenge:welten/start
execute if score #m_mut sb.cfg matches 1 run function challenge:mutation/bossbar
execute if score #m_mut sb.cfg matches 1 if score #m_perm sb.cfg matches 1 run tellraw @a [{"text":"♾ Mutationen sind dauerhaft: ","color":"light_purple","bold":true},{"text":"jede neue kommt oben drauf. Eine Lagerfeuer-Rast nimmt euch die neueste wieder ab.","color":"gray"}]
execute if score #m_mut sb.cfg matches 0 run bossbar set challenge:main name {"text":"⚔ CHALLENGE ⚔","color":"gold","bold":true}
title @a times 10 60 20
execute if score #goal sb.cfg matches 1 run title @a subtitle {"text":"Ziel: Enderdrache","color":"light_purple"}
execute if score #goal sb.cfg matches 2 run title @a subtitle {"text":"Ziel: Wither","color":"dark_gray"}
execute if score #goal sb.cfg matches 3 run title @a subtitle {"text":"Ziel: Wärter","color":"dark_aqua"}
execute if score #goal sb.cfg matches 4 run title @a subtitle {"text":"Ziel: Ältester Wächter","color":"aqua"}
execute if score #goal sb.cfg matches 5 run title @a subtitle {"text":"Ziel: Alle vier Bosse","color":"gold"}
execute if score #goal sb.cfg matches 6 run title @a subtitle {"text":"Ziel: Seelenwelten: Der Ronin","color":"dark_purple"}
title @a title {"text":"LOS GEHT'S!","color":"light_purple","bold":true}
execute as @a at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.6 1.2
execute if score #preset sb.cfg matches 1 run tellraw @a [{"text":"⛓ Modus: ","color":"gray"},{"text":"Entspannt","color":"light_purple","bold":true},{"text":" – Normal • Seelenband 64 Blöcke • natürliche Regeneration an","color":"gray"}]
execute if score #preset sb.cfg matches 2 run tellraw @a [{"text":"⛓ Modus: ","color":"gray"},{"text":"Standard","color":"light_purple","bold":true},{"text":" – Schwer • Seelenband 40 Blöcke • natürliche Regeneration an (empfohlen)","color":"gray"}]
execute if score #preset sb.cfg matches 3 run tellraw @a [{"text":"⛓ Modus: ","color":"gray"},{"text":"Wahnsinn","color":"light_purple","bold":true},{"text":" – Schwer • Seelenband 24 Blöcke • KEINE natürliche Regeneration","color":"gray"}]
execute if score #preset sb.cfg matches 0 run function challenge:settings/announce_custom
execute if score #goal sb.cfg matches 1 run tellraw @a [{"text":"✪ Ziel: ","color":"gray"},{"text":"Enderdrache","color":"light_purple","bold":true}]
execute if score #goal sb.cfg matches 2 run tellraw @a [{"text":"✪ Ziel: ","color":"gray"},{"text":"Wither","color":"dark_gray","bold":true}]
execute if score #goal sb.cfg matches 3 run tellraw @a [{"text":"✪ Ziel: ","color":"gray"},{"text":"Wärter","color":"dark_aqua","bold":true}]
execute if score #goal sb.cfg matches 4 run tellraw @a [{"text":"✪ Ziel: ","color":"gray"},{"text":"Ältester Wächter","color":"aqua","bold":true}]
execute if score #goal sb.cfg matches 5 run tellraw @a [{"text":"✪ Ziel: ","color":"gray"},{"text":"Alle vier Bosse","color":"gold","bold":true}]
execute if score #goal sb.cfg matches 6 run tellraw @a [{"text":"✪ Ziel: ","color":"gray"},{"text":"Seelenwelten: Der Ronin","color":"dark_purple","bold":true}]
execute if score #death sb.cfg matches 1 run tellraw @a [{"text":"☠ Ein Leben: ","color":"dark_red","bold":true},{"text":"Stirbt einer, ist die Challenge für alle vorbei.","color":"gray"},{"text":"  "},{"text":"[? REGELN]","color":"aqua","bold":true,"click_event":{"action":"run_command","command":"/trigger challenge set 12"},"hover_event":{"action":"show_text","value":{"text":"Alle Regeln anzeigen"}}}]
execute if score #death sb.cfg matches 2 run tellraw @a [{"text":"☠ Hardcore: ","color":"dark_red","bold":true},{"text":"Wer stirbt, scheidet aus. Verloren ist erst, wenn alle tot sind.","color":"gray"},{"text":"  "},{"text":"[? REGELN]","color":"aqua","bold":true,"click_event":{"action":"run_command","command":"/trigger challenge set 12"},"hover_event":{"action":"show_text","value":{"text":"Alle Regeln anzeigen"}}}]
