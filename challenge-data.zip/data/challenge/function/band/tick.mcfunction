execute store result score #n sb if entity @a[tag=sb.player,gamemode=survival]
execute if score #n sb matches ..1 run return run scoreboard players set @a sb.band 0
execute as @a[tag=sb.player,gamemode=survival] at @s run function challenge:band/check with storage challenge:cfg
