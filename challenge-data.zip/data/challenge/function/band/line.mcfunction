scoreboard players add #steps sb 1
execute if score #linetype sb matches 2 run particle minecraft:soul_fire_flame ~ ~ ~ 0 0 0 0 1 force @a
execute if score #linetype sb matches 3 run particle minecraft:flame ~ ~ ~ 0 0 0 0 1 force @a
execute if score #steps sb matches 150.. run return 0
execute if entity @a[tag=sb.partner,distance=..2] run return 0
execute positioned ^ ^ ^1 run function challenge:band/line
