tag @s add sb.self
scoreboard players set @s sb.band 4
execute if entity @a[tag=sb.player,gamemode=survival,tag=!sb.self,distance=0..] run scoreboard players set @s sb.band 3
$execute if entity @a[tag=sb.player,gamemode=survival,tag=!sb.self,distance=..$(max)] run scoreboard players set @s sb.band 2
$execute if entity @a[tag=sb.player,gamemode=survival,tag=!sb.self,distance=..$(warn)] run scoreboard players set @s sb.band 1
execute if score @s sb.band matches ..3 run scoreboard players set @s sb.dimt 0
execute if score @s sb.band matches 2..3 run function challenge:band/draw
execute if score #t sb matches 0 if score @s sb.band matches 3 run damage @s 2 challenge:band
execute if score #t sb matches 0 if score @s sb.band matches 4 run scoreboard players add @s sb.dimt 1
execute if score #t sb matches 0 if score @s sb.band matches 4 if score @s sb.dimt matches 31.. run damage @s 2 challenge:band
tag @s remove sb.self
