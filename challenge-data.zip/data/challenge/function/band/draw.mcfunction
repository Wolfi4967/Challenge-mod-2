tag @a[tag=sb.player,gamemode=survival,tag=!sb.self,distance=0..,sort=nearest,limit=1] add sb.partner
scoreboard players set #steps sb 0
scoreboard players operation #linetype sb = @s sb.band
execute anchored eyes positioned ^ ^ ^ anchored feet facing entity @a[tag=sb.partner,limit=1] eyes run function challenge:band/line
scoreboard players operation @s sb.dist = #steps sb
tag @a remove sb.partner
