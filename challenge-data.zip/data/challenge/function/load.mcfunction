# Challenge-Mod • wird bei jedem Laden ausgefuehrt
scoreboard objectives add sb dummy
scoreboard objectives add sb.cfg dummy
scoreboard objectives add sb.const dummy
scoreboard objectives add sb.tmp dummy
scoreboard objectives add sb.dmg minecraft.custom:minecraft.damage_taken
scoreboard objectives add sb.pending dummy
scoreboard objectives add sb.deaths deathCount
scoreboard objectives add sb.mut dummy
scoreboard objectives add sb.band dummy
scoreboard objectives add sb.dist dummy
scoreboard objectives add sb.dimt dummy
scoreboard objectives add sb.sneak minecraft.custom:minecraft.sneak_time
scoreboard objectives add sb.mnv dummy
scoreboard objectives add sb.bvar dummy
scoreboard objectives add sb.dim dummy
scoreboard objectives add sb.dimtime dummy
scoreboard objectives add sb.follow dummy
scoreboard objectives add sb.mhu dummy
scoreboard objectives add sb.kwither minecraft.killed:minecraft.wither
scoreboard objectives add sb.kwarden minecraft.killed:minecraft.warden
scoreboard objectives add sb.kelder minecraft.killed:minecraft.elder_guardian
scoreboard objectives add start_challenge trigger {"text":"Challenge starten"}
scoreboard objectives add pause_challenge trigger {"text":"Challenge pausieren"}
scoreboard objectives add disable_challenge trigger {"text":"Challenge deaktivieren"}
scoreboard objectives add challenge trigger {"text":"Challenge-Menü"}
scoreboard objectives add sb.hp health {"text":"❤","color":"red"}
scoreboard objectives modify sb.hp rendertype hearts
scoreboard players set #10 sb.const 10
scoreboard players set #20 sb.const 20
scoreboard players set #60 sb.const 60
scoreboard players set #3600 sb.const 3600
scoreboard players set #2 sb.const 2
# Add-ons melden sich 1 Tick nach dem Laden selbst an
scoreboard players set #addon_block sb 0
scoreboard players set #addon_biome sb 0
scoreboard players set #addon_welten sb 0
scoreboard objectives add sb.role dummy
bossbar add challenge:main {"text":"⚔ Challenge"}
execute if score #state sb matches 4 run bossbar set challenge:main visible false
bossbar set challenge:main max 100
bossbar set challenge:main value 100
execute unless score #init sb matches 1 run function challenge:init
# Werte nachruesten, falls die Welt mit einer aelteren Version erstellt wurde
execute unless score #diff sb.cfg matches 1..3 run scoreboard players set #diff sb.cfg 3
execute unless score #regen sb.cfg matches 0..1 run scoreboard players set #regen sb.cfg 1
execute unless score #m_perm sb.cfg matches 0..1 run scoreboard players set #m_perm sb.cfg 0
execute unless score #m_uhc sb.cfg matches 0..1 run scoreboard players set #m_uhc sb.cfg 0
execute unless score #m_chain sb.cfg matches 0..1 run scoreboard players set #m_chain sb.cfg 0
execute unless score #chain_len sb.cfg matches 3..20 run scoreboard players set #chain_len sb.cfg 6
execute unless score #m_mobrand sb.cfg matches 0..1 run scoreboard players set #m_mobrand sb.cfg 0
execute unless score #m_fx sb.cfg matches 0..1 run scoreboard players set #m_fx sb.cfg 0
execute unless score #m_brand sb.cfg matches 0..1 run scoreboard players set #m_brand sb.cfg 0
execute unless score #m_cshift sb.cfg matches 0..1 run scoreboard players set #m_cshift sb.cfg 0
execute unless score #m_cbiome sb.cfg matches 0..1 run scoreboard players set #m_cbiome sb.cfg 0
execute unless score #m_mobdrop sb.cfg matches 0..1 run scoreboard players set #m_mobdrop sb.cfg 0
execute unless score #m_chest sb.cfg matches 0..1 run scoreboard players set #m_chest sb.cfg 0
execute unless score #cshift_max sb.cfg matches 4..24 run scoreboard players set #cshift_max sb.cfg 12
execute unless score #m_craft sb.cfg matches 0..1 run scoreboard players set #m_craft sb.cfg 0
execute unless score #goal sb.cfg matches 1..6 run scoreboard players set #goal sb.cfg 1
execute unless score #death sb.cfg matches 1..2 run scoreboard players set #death sb.cfg 1
execute unless score #bvar sb matches 1..3 store result score #bvar sb run random value 1..3
execute unless score #fx_t sb matches 0.. run scoreboard players set #fx_t sb 0
execute unless score #mver sb.mut matches -2147483648.. run function challenge:mutation/reset_flags
execute unless score #band_max sb.cfg matches 8..200 run scoreboard players set #band_max sb.cfg 40
function challenge:settings/sync
