effect give @a[tag=sb.player,gamemode=survival] minecraft:glowing 60 0
title @a[tag=sb.player] times 5 40 10
title @a[tag=sb.player] subtitle [{"text":"✖ 60 Sekunden","color":"red"}]
title @a[tag=sb.player] title {"text":"⚡ Leuchtreklame","color":"red","bold":true}
tellraw @a [{"text":"⚡ Zufallseffekt: ","color":"yellow"},{"text":"Leuchtreklame","color":"red","bold":true},{"text":" (60 s)","color":"gray"}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 0.6
