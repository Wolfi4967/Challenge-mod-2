effect give @a[tag=sb.player,gamemode=survival] minecraft:slowness 30 1
title @a[tag=sb.player] times 5 40 10
title @a[tag=sb.player] subtitle [{"text":"✖ 30 Sekunden","color":"red"}]
title @a[tag=sb.player] title {"text":"⚡ Schnecke","color":"red","bold":true}
tellraw @a [{"text":"⚡ Zufallseffekt: ","color":"yellow"},{"text":"Schnecke","color":"red","bold":true},{"text":" (30 s)","color":"gray"}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 0.6
