effect give @a[tag=sb.player,gamemode=survival] minecraft:weakness 30 0
title @a[tag=sb.player] times 5 40 10
title @a[tag=sb.player] subtitle [{"text":"✖ 30 Sekunden","color":"red"}]
title @a[tag=sb.player] title {"text":"⚡ Schwächeanfall","color":"red","bold":true}
tellraw @a [{"text":"⚡ Zufallseffekt: ","color":"yellow"},{"text":"Schwächeanfall","color":"red","bold":true},{"text":" (30 s)","color":"gray"}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 0.6
