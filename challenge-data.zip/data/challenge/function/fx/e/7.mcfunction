effect give @a[tag=sb.player,gamemode=survival] minecraft:absorption 60 1
title @a[tag=sb.player] times 5 40 10
title @a[tag=sb.player] subtitle [{"text":"✚ 60 Sekunden","color":"green"}]
title @a[tag=sb.player] title {"text":"⚡ Schutzherzen","color":"green","bold":true}
tellraw @a [{"text":"⚡ Zufallseffekt: ","color":"yellow"},{"text":"Schutzherzen","color":"green","bold":true},{"text":" (60 s)","color":"gray"}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 1.6
