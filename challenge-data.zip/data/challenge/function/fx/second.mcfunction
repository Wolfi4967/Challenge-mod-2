scoreboard players add #fx_t sb 1
execute if score #fx_t sb matches 300.. run function challenge:fx/roll
