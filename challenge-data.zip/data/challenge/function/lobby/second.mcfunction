gamemode adventure @a[gamemode=survival]
effect give @a[gamemode=adventure] minecraft:resistance 3 4 true
effect give @a[gamemode=adventure] minecraft:saturation 3 0 true
effect give @a[gamemode=adventure] minecraft:regeneration 3 1 true
bossbar set challenge:main name [{"text":"⚔ CHALLENGE ⚔","color":"gold","bold":true},{"text":"  Lobby • Menü: Taste G oder /challenge","color":"gray"}]
bossbar set challenge:main color purple
bossbar set challenge:main value 100
