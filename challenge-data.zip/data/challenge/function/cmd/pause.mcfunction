function challenge:menu/pause
scoreboard players set @s pause_challenge 0
