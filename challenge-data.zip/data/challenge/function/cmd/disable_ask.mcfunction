# offenes Menüfenster schließen (die Fenster bleiben nach einem Klick offen, bis der Server antwortet)
execute if entity @s run dialog clear @s
execute if score #state sb matches 4 run return run tellraw @s [{"text":"Die Challenge ist schon deaktiviert. ","color":"gray"},{"text":"[↻ Wieder aktivieren]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger challenge set 17"},"hover_event":{"action":"show_text","value":{"text":"Zurück in die Lobby – danach neu starten"}}}]
tellraw @s [{"text":"⚠ Challenge wirklich deaktivieren? ","color":"gold"},{"text":"[JA, DEAKTIVIEREN]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger challenge set 16"},"hover_event":{"action":"show_text","value":{"text":"Alle Regeln aus, Mutationen weg, Timer stoppt"}}}]
function challenge:ui/open_confirm_disable
