execute if score #state sb matches 2..4 run return run function challenge:game/to_lobby_menu
function challenge:cmd/start_now
