function challenge:cmd/start_logic
scoreboard players set @s start_challenge 0
