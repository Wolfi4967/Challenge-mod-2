# offenes Menüfenster schließen (die Fenster bleiben nach einem Klick offen, bis der Server antwortet)
execute if entity @s run dialog clear @s
execute unless score #state sb matches 0 run return run tellraw @s {"text":"✖ Die Challenge läuft bereits.","color":"red"}
execute if score #countdown sb matches 1.. run return 0
execute if score #goal sb.cfg matches 6 unless score #addon_welten sb matches 1 run return run function challenge:welten/missing
execute store result score #n sb if entity @a[gamemode=!spectator]
execute if score #n sb matches ..1 run tellraw @a {"text":"⚠ Nur ein Spieler online – Seelenband, Kette & geteilter Schmerz wirken erst ab zwei Spielern.","color":"gold"}
tellraw @a [{"selector":"@s","color":"yellow"},{"text":" startet die Challenge!","color":"gray"}]
title @a times 0 25 5
scoreboard players set #countdown sb 4
function challenge:start/countdown
