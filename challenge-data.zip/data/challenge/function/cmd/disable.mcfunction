execute if score @s disable_challenge matches 2 run function challenge:game/disable
execute unless score @s disable_challenge matches 2 run function challenge:cmd/disable_ask
scoreboard players set @s disable_challenge 0
