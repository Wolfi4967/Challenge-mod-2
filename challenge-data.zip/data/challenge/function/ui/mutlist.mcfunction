data modify storage challenge:ui ml set value {type:"minecraft:plain_message",contents:[{text:"♾ Aktiv: ",color:"gray"}],width:310}
execute if score #count sb.mut matches 0 run data modify storage challenge:ui ml.contents append value {text:"noch keine",color:"dark_gray"}
execute if score #a1 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Windläufer  ",color:"green"}
execute if score #a2 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Bergziege  ",color:"green"}
execute if score #a3 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Titanhaut  ",color:"green"}
execute if score #a4 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Lange Arme  ",color:"green"}
execute if score #a5 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Bergmann  ",color:"green"}
execute if score #a6 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Berserker  ",color:"green"}
execute if score #a7 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Extraherzen  ",color:"green"}
execute if score #a8 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Katzenaugen  ",color:"green"}
execute if score #a9 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Glaskörper  ",color:"red"}
execute if score #a10 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Bleifüße  ",color:"red"}
execute if score #a11 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Morsche Knochen  ",color:"red"}
execute if score #a12 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Schwächling  ",color:"red"}
execute if score #a13 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Kurze Arme  ",color:"red"}
execute if score #a14 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Zunder  ",color:"red"}
execute if score #a15 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Vielfraß  ",color:"red"}
execute if score #a16 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Riese  ",color:"light_purple"}
execute if score #a17 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Zwerg  ",color:"light_purple"}
execute if score #a18 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Mondschwerkraft  ",color:"light_purple"}
execute if score #a19 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Hüpfburg  ",color:"light_purple"}
execute if score #a20 sb.mut matches 1 run data modify storage challenge:ui ml.contents append value {text:"Koffeinschock  ",color:"light_purple"}
data modify storage challenge:ui dlg.body append from storage challenge:ui ml
