$dialog show @s $(dlg)
