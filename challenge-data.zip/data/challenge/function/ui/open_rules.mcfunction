data remove storage challenge:ui dlg
data modify storage challenge:ui v set value {dist:40}
execute store result storage challenge:ui v.dist int 1 run scoreboard players get #band_max sb.cfg
function challenge:ui/build_rules with storage challenge:ui v
function challenge:ui/present
