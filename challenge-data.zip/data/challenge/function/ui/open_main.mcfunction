data remove storage challenge:ui dlg
function challenge:ui/collect
function challenge:ui/build_main with storage challenge:ui v
execute if score #lockmsg sb matches 1 run data modify storage challenge:ui dlg.body prepend value {type:"minecraft:plain_message",contents:{text:"✖ Einstellungen lassen sich nur in der Lobby ändern – also bevor die Challenge gestartet wurde.",color:"red"},width:310}
scoreboard players set #lockmsg sb 0
execute if score #state sb matches 1..3 run data modify storage challenge:ui dlg.body append from storage challenge:ui lines.time
execute if score #state sb matches 1..3 run data modify storage challenge:ui dlg.body append from storage challenge:ui lines.progress
execute if score #state sb matches 1..3 if score #m_mut sb.cfg matches 1 if score #m_perm sb.cfg matches 1 run function challenge:ui/mutlist
execute unless score #state sb matches 4 run data modify storage challenge:ui dlg.body append from storage challenge:ui lines.goal
execute unless score #state sb matches 4 run data modify storage challenge:ui dlg.body append from storage challenge:ui lines.settings
execute unless score #state sb matches 4 if score #m_band sb.cfg matches 1 run data modify storage challenge:ui dlg.body append from storage challenge:ui lines.band
execute unless score #state sb matches 4 if score #m_band sb.cfg matches 0 run data modify storage challenge:ui dlg.body append from storage challenge:ui lines.band_off
execute unless score #state sb matches 4 run data modify storage challenge:ui dlg.body append from storage challenge:ui lines.modules
execute unless score #state sb matches 4 run data modify storage challenge:ui dlg.body append from storage challenge:ui lines.modules2
data modify storage challenge:ui dlg.body append from storage challenge:ui lines.addons
# Buttons je nach Spielstand
scoreboard players set #lobby sb 0
execute if score #state sb matches 0 unless score #countdown sb matches 1.. run scoreboard players set #lobby sb 1
execute if score #lobby sb matches 1 run data modify storage challenge:ui dlg.body append from storage challenge:ui lines.lobby_hint
execute if score #lobby sb matches 1 run data modify storage challenge:ui dlg.actions append value {label:{text:"▶ Challenge starten",color:"green",bold:true},tooltip:{text:"Startet den Countdown – danach gibt es kein Zurück!"},width:220,action:{type:"minecraft:run_command",command:"challenge start"}}
execute if score #lobby sb matches 1 run data modify storage challenge:ui dlg.actions append value {label:{text:"⚙ Regeln & Distanz",color:"gold"},tooltip:{text:"Seite 1: Seelenband-Distanz, Schwierigkeit, Regeneration, Ultra Hardcore"},width:220,action:{type:"minecraft:run_command",command:"challenge settings"}}
execute if score #lobby sb matches 1 run data modify storage challenge:ui dlg.actions append value {label:{text:"⚄ Chaos, Kette & Randomizer",color:"light_purple"},tooltip:{text:"Seite 2: Kette, Mutationen, Mob-Randomizer, Zufallseffekte"},width:220,action:{type:"minecraft:run_command",command:"challenge chaos"}}
execute if score #lobby sb matches 1 run data modify storage challenge:ui dlg.actions append value {label:{text:"✪ Ziel & Leben",color:"yellow"},tooltip:{text:"Seite 3: Ziel (Drache, Wither, Wärter …) und was beim Tod passiert"},width:220,action:{type:"minecraft:run_command",command:"challenge goal"}}
execute if score #state sb matches 1 if score #paused sb matches 0 run data modify storage challenge:ui dlg.actions append value {label:{text:"⏸ Pausieren",color:"gold",bold:true},tooltip:{text:"Timer anhalten und euch beide einfrieren"},width:220,action:{type:"minecraft:run_command",command:"challenge pause"}}
execute if score #state sb matches 1 if score #paused sb matches 1 run data modify storage challenge:ui dlg.actions append value {label:{text:"▶ Fortsetzen",color:"green",bold:true},tooltip:{text:"Weiterspielen"},width:220,action:{type:"minecraft:run_command",command:"challenge pause"}}
execute if score #state sb matches 2..3 run data modify storage challenge:ui dlg.actions append value {label:{text:"★ Statistik im Chat",color:"yellow"},tooltip:{text:"Zeit, Advancements, Mutationen, geteilter Schaden"},width:220,action:{type:"minecraft:run_command",command:"challenge stats"}}
execute if score #state sb matches 2..3 run data modify storage challenge:ui dlg.actions append value {label:{text:"↻ Neuer Versuch in dieser Welt",color:"green"},tooltip:{text:"Zurück in die Lobby (fairer ist eine neue Welt)"},width:220,action:{type:"minecraft:run_command",command:"challenge setup"}}
execute if score #state sb matches 4 run data modify storage challenge:ui dlg.actions append value {label:{text:"⚔ Challenge einrichten",color:"green",bold:true},tooltip:{text:"In die Lobby: Einstellungen wählen und dann starten"},width:220,action:{type:"minecraft:run_command",command:"challenge setup"}}
data modify storage challenge:ui dlg.actions append value {label:{text:"? Regeln",color:"aqua"},tooltip:{text:"Alle Regeln der Challenge"},width:220,action:{type:"minecraft:run_command",command:"challenge rules"}}
execute if score #state sb matches 0..3 run data modify storage challenge:ui dlg.actions append value {label:{text:"⛔ Challenge deaktivieren",color:"red"},tooltip:{text:"Alle Regeln ausschalten – mit Rückfrage"},width:220,action:{type:"minecraft:run_command",command:"challenge disable"}}
function challenge:ui/present
