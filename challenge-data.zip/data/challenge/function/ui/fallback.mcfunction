tellraw @s {"text":"⚠ Das Menüfenster konnte nicht erstellt werden – hier ist das Chat-Menü:","color":"red"}
function challenge:menu/show
