# offenes Menüfenster schließen (die Fenster bleiben nach einem Klick offen, bis der Server antwortet)
execute if entity @s run dialog clear @s
tellraw @s {"text":"⚠ Das Menüfenster konnte nicht erstellt werden – hier ist das Chat-Menü:","color":"red"}
function challenge:menu/show
