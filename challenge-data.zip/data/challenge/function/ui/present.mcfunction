# Sicherung: Wenn der Dialog nicht gebaut wurde, nie einen alten anzeigen -> Chat-Menü
execute unless data storage challenge:ui dlg.type run return run function challenge:ui/fallback
function challenge:ui/show with storage challenge:ui
