execute if score #won_elder sb matches 1 run return 0
scoreboard players set #won_elder sb 1
title @a times 10 50 20
title @a subtitle {"text":"besiegt!","color":"yellow"}
title @a title {"text":"Ältester Wächter","color":"aqua","bold":true}
tellraw @a [{"text":"✪ ","color":"gold"},{"text":"Ältester Wächter","color":"aqua","bold":true},{"text":" wurde besiegt!","color":"yellow"}]
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.3
function challenge:goal/evaluate
