execute unless score #state sb matches 1 run return 0
execute if score #goal sb.cfg matches 1 if score #won_dragon sb matches 1 run return run function challenge:win/win
execute if score #goal sb.cfg matches 2 if score #won_wither sb matches 1 run return run function challenge:win/win
execute if score #goal sb.cfg matches 3 if score #won_warden sb matches 1 run return run function challenge:win/win
execute if score #goal sb.cfg matches 4 if score #won_elder sb matches 1 run return run function challenge:win/win
execute if score #goal sb.cfg matches 5 if score #won_dragon sb matches 1 if score #won_wither sb matches 1 if score #won_warden sb matches 1 if score #won_elder sb matches 1 run return run function challenge:win/win
