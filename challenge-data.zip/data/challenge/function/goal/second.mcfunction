execute if score #won_wither sb matches 0 if entity @a[tag=sb.player,scores={sb.kwither=1..}] run function challenge:goal/got_wither
execute if score #won_warden sb matches 0 if entity @a[tag=sb.player,scores={sb.kwarden=1..}] run function challenge:goal/got_warden
execute if score #won_elder sb matches 0 if entity @a[tag=sb.player,scores={sb.kelder=1..}] run function challenge:goal/got_elder
function challenge:goal/evaluate
