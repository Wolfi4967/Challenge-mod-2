scoreboard players enable @a challenge
scoreboard players enable @a start_challenge
scoreboard players enable @a pause_challenge
scoreboard players enable @a disable_challenge
execute as @a[scores={challenge=1..}] run function challenge:menu/handle
execute as @a[scores={start_challenge=1..}] run function challenge:cmd/start
execute as @a[scores={pause_challenge=1..}] run function challenge:cmd/pause
execute as @a[scores={disable_challenge=1..}] run function challenge:cmd/disable
scoreboard players add #t sb 1
execute if score #t sb matches 20.. run scoreboard players set #t sb 0
execute if score #state sb matches 1 run function challenge:game/tick
execute if score #t sb matches 0 run function challenge:second
execute if score #t sb matches 0 run function challenge:hud/update
execute if score #t sb matches 10 run function challenge:hud/update
